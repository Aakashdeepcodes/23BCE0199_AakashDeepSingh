# Library Management System — Backend

A production-grade Library Management System REST API built with **Node.js, Express, MongoDB, and Mongoose**. It includes JWT authentication, role-based access control, full circulation logic (issue / return / renew), automatic fine calculation, notifications, aggregation-based reports, audit logging, and Swagger documentation.

## Tech Stack

- **Runtime:** Node.js 18+ / Express 4
- **Database:** MongoDB + Mongoose 8 (ODM)
- **Auth:** JWT (access + refresh tokens), bcrypt password hashing
- **Validation:** Joi
- **Logging:** Winston (daily-rotating files) + Morgan (HTTP)
- **Security:** Helmet, CORS, rate limiting, mongo-sanitize, hpp
- **Docs:** Swagger / OpenAPI 3 (`swagger-jsdoc` + `swagger-ui-express`)
- **Testing:** Jest + Supertest + mongodb-memory-server

## Features

- **10 collections:** Users, Roles, Books, Authors, Categories, Publishers, Transactions, Fines, Notifications, AuditLogs
- Mongoose schemas with required fields, unique constraints, ObjectId references, population, validation, text + compound indexes, virtuals, and a TTL index on audit logs
- Role-based (admin / librarian / member) **and** fine-grained permission authorization
- Circulation engine with MongoDB multi-document transactions (auto-fallback for standalone Mongo), borrowing limits, outstanding-fine blocks, renewals, and overdue handling
- Automatic fine computation for overdue / lost / damaged returns
- Aggregation-pipeline reports: dashboard, most-borrowed books, top members, fine summary, monthly circulation trend, inventory by category
- Centralized error handling, async wrappers, standardized response envelopes, pagination + sorting

## Getting Started

### Prerequisites
- Node.js 18+
- A running MongoDB instance (local or Atlas)

### Install
```bash
npm install
cp .env.example .env   # then edit values, especially JWT secrets and MONGO_URI
```

### Seed initial data (roles, admin user, sample catalog)
```bash
npm run seed
```
Default admin (from `.env`): `admin@library.com` / `Admin@12345`

### Run
```bash
npm run dev     # development with nodemon
npm start       # production
```

- API base: `http://localhost:5000/api/v1`
- Swagger UI: `http://localhost:5000/api-docs`
- Health check: `GET /api/v1/health`

### Test
```bash
npm test
```
> Integration tests use an in-memory MongoDB. In environments without internet access (where the Mongo binary cannot be downloaded), the DB-dependent tests skip gracefully while the rest still run.

## Project Structure

```
src/                    # Backend (Node/Express/Mongoose)
  config/        # env, logger, database, swagger
  models/        # 10 Mongoose models
  validators/    # Joi schemas
  middleware/    # auth, validation, audit, error, rate-limit
  services/      # business logic
  controllers/   # request handlers
  routes/        # Express routers (with Swagger JSDoc)
  utils/         # ApiError, helpers, token, seed
  app.js         # Express app assembly
  server.js      # entry point + graceful shutdown
tests/
  api.test.js    # integration tests
frontend/               # Frontend (React + Vite SPA)
  src/
    api/         # axios client with token-refresh interceptor
    context/     # auth + toast providers
    components/  # Layout, shared UI
    pages/       # Login, Dashboard, Catalog, Loans, Circulation,
                 #   Members, Fines, Notices, Audit
    styles/      # design system ("The Stacks" catalog-card theme)
```

## Frontend ("The Stacks")

A React + Vite single-page app styled as a library catalog room — ink-on-paper
palette, Fraunces display serif, monospace call-numbers, oxblood spine-red accent.
It talks to the backend over REST and covers the full workflow:

- **Sign in / register** with JWT (access + auto-refresh)
- **Reading Room** — role-aware dashboard (library health for staff; borrowing record for members)
- **Catalog** — search, browse, and (staff) add titles
- **My Loans** — view and renew your borrowed books
- **Circulation** (staff) — issue, return, condition handling, overdue sweep
- **Members** (staff), **Fines** (pay/waive), **Notices**, **Audit Log** (admin)

### Run the frontend
```bash
cd frontend
npm install
cp .env.example .env     # VITE_API_BASE_URL defaults to /api/v1
npm run dev              # http://localhost:5173 (proxies /api to :5000)
```
Start the backend first (`npm run dev` in the project root) and seed it, then
sign in with the seeded admin (`admin@library.com` / `Admin@12345`) or register a member.

## Core API Endpoints

| Method | Path | Access | Description |
|--------|------|--------|-------------|
| POST | `/auth/register` | public | Register a member |
| POST | `/auth/login` | public | Login, get tokens |
| POST | `/auth/refresh` | public | Refresh tokens |
| GET  | `/auth/me` | auth | Current user |
| GET/POST | `/books` | public / staff | List-search / create |
| GET/PUT/DELETE | `/books/:id` | public / staff | Read / update / soft-delete |
| GET | `/books/stats/by-category` | staff | Inventory aggregation |
| CRUD | `/authors` `/categories` `/publishers` | public / staff | Catalog management |
| POST | `/transactions/issue` | staff | Issue a book |
| POST | `/transactions/:id/return` | staff | Return a book |
| POST | `/transactions/:id/renew` | auth | Renew a loan |
| GET | `/transactions/my-loans` | auth | Member's own loans |
| GET | `/fines` `/fines/my-fines` | staff / auth | Fines |
| POST | `/fines/:id/pay` `/fines/:id/waive` | staff | Settle fines |
| GET/PATCH | `/notifications` | auth | Notifications |
| CRUD | `/users` | staff / admin | User management |
| GET | `/reports/*` | staff | Dashboard & reports |
| GET | `/audit-logs` | admin | Audit trail |

## Environment Variables

See `.env.example` for the full list — server, MongoDB URIs, JWT secrets/expiry, bcrypt rounds, rate limits, and library business rules (loan days, max books per user, fine per day, max renewals).

## License

MIT
