import axios from 'axios';

const BASE = import.meta.env.VITE_API_BASE_URL || '/api/v1';

const api = axios.create({ baseURL: BASE });

// Attach access token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// On 401, try a single refresh then replay the request
let refreshing = null;
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    const status = error.response?.status;
    const refreshToken = localStorage.getItem('refreshToken');

    if (status === 401 && refreshToken && !original._retry && !original.url.includes('/auth/')) {
      original._retry = true;
      try {
        if (!refreshing) {
          refreshing = axios.post(`${BASE}/auth/refresh`, { refreshToken });
        }
        const { data } = await refreshing;
        refreshing = null;
        localStorage.setItem('accessToken', data.data.tokens.accessToken);
        localStorage.setItem('refreshToken', data.data.tokens.refreshToken);
        original.headers.Authorization = `Bearer ${data.data.tokens.accessToken}`;
        return api(original);
      } catch (e) {
        refreshing = null;
        localStorage.clear();
        window.location.href = '/login';
        return Promise.reject(e);
      }
    }
    return Promise.reject(error);
  }
);

// Normalize error message extraction
export const errMsg = (e) =>
  e?.response?.data?.errors?.map((x) => x.message).join(', ')
  || e?.response?.data?.message
  || e?.message
  || 'Something went wrong';

export default api;
