import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadMe = useCallback(async () => {
    if (!localStorage.getItem('accessToken')) {
      setLoading(false);
      return;
    }
    try {
      const { data } = await api.get('/auth/me');
      setUser(data.data.user);
    } catch {
      localStorage.clear();
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadMe(); }, [loadMe]);

  const persist = (payload) => {
    localStorage.setItem('accessToken', payload.tokens.accessToken);
    localStorage.setItem('refreshToken', payload.tokens.refreshToken);
    setUser(payload.user);
  };

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    persist(data.data);
    return data.data.user;
  };

  const register = async (form) => {
    const { data } = await api.post('/auth/register', form);
    persist(data.data);
    return data.data.user;
  };

  const logout = async () => {
    try { await api.post('/auth/logout'); } catch { /* ignore */ }
    localStorage.clear();
    setUser(null);
  };

  const role = user?.role?.name;
  const isStaff = role === 'admin' || role === 'librarian';
  const isAdmin = role === 'admin';

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, role, isStaff, isAdmin, refresh: loadMe }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
