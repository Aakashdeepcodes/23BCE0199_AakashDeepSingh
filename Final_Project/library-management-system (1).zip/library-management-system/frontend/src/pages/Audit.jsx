import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function Audit() {
  const toast = useToast();
  const [logs, setLogs] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);

  const load = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const { data } = await api.get('/audit-logs', { params: { page: p, limit: 20, sort: '-createdAt' } });
      setLogs(data.data.logs);
      setMeta(data.meta);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { load(page); }, [page, load]);

  return (
    <>
      <Topbar title="Audit Log" sub="Every privileged action, on the record" />
      <div className="content">
        <div className="panel">
          {loading ? <Loading /> : logs.length === 0 ? (
            <Empty title="No entries yet" sub="Staff actions will be logged here." mark="❧" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>When</th>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Method</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((l) => (
                    <tr key={l._id}>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>{new Date(l.createdAt).toLocaleString()}</td>
                      <td>{l.actor?.name || l.actorEmail || '—'}</td>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>{l.action}</td>
                      <td>{l.entity}</td>
                      <td className="mono" style={{ fontSize: '0.8rem' }}>{l.method}</td>
                      <td className="mono">{l.statusCode}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>
    </>
  );
}
