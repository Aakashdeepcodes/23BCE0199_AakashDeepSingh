import { useEffect, useState } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

function StatCard({ label, value, foot }) {
  return (
    <div className="stat">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {foot && <div className="foot">{foot}</div>}
    </div>
  );
}

export default function Dashboard() {
  const { isStaff, user } = useAuth();
  const toast = useToast();
  const [stats, setStats] = useState(null);
  const [borrowed, setBorrowed] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (isStaff) {
          const [d, mb] = await Promise.all([
            api.get('/reports/dashboard'),
            api.get('/reports/most-borrowed?limit=6'),
          ]);
          if (!alive) return;
          setStats(d.data.data);
          setBorrowed(mb.data.data.books);
        } else {
          const loans = await api.get('/transactions/my-loans?limit=100');
          if (!alive) return;
          const items = loans.data.data.transactions;
          const active = items.filter((t) => t.status === 'issued' || t.status === 'overdue');
          setStats({
            activeLoans: active.length,
            overdueLoans: active.filter((t) => new Date(t.dueDate) < new Date()).length,
            pendingFineAmount: user?.outstandingFine || 0,
            totalLoans: items.length,
          });
        }
      } catch (e) {
        toast.error(errMsg(e));
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, [isStaff, user, toast]);

  const maxBorrow = Math.max(1, ...borrowed.map((b) => b.borrowCount));

  return (
    <>
      <Topbar
        title={isStaff ? 'Reading Room' : `Welcome back, ${user?.name?.split(' ')[0]}`}
        sub={isStaff ? 'Library health at a glance' : 'Your borrowing record'}
      />
      <div className="content">
        {loading ? <Loading /> : (
          <>
            <div className="stat-grid">
              {isStaff ? (
                <>
                  <StatCard label="Titles" value={stats.totalBooks} foot={`${stats.totalCopies} copies total`} />
                  <StatCard label="On loan" value={stats.copiesOnLoan} foot={`${stats.availableCopies} available`} />
                  <StatCard label="Active loans" value={stats.activeLoans} foot={`${stats.overdueLoans} overdue`} />
                  <StatCard label="Members" value={stats.totalMembers} />
                  <StatCard label="Fines pending" value={`₹${stats.pendingFineAmount}`} foot="awaiting payment" />
                </>
              ) : (
                <>
                  <StatCard label="Active loans" value={stats.activeLoans} foot={`${stats.overdueLoans} overdue`} />
                  <StatCard label="Membership" value={user?.membershipId?.split('-').pop() || '—'} foot={user?.membershipId} />
                  <StatCard label="Fines due" value={`₹${stats.pendingFineAmount}`} foot={stats.pendingFineAmount > 0 ? 'please settle' : 'all clear'} />
                  <StatCard label="Lifetime loans" value={stats.totalLoans} />
                </>
              )}
            </div>

            {isStaff && (
              <div className="dash-cols">
                <div className="panel pad">
                  <div className="section-head">
                    <h2>Most borrowed</h2>
                    <span className="count">all-time</span>
                  </div>
                  {borrowed.length === 0 ? (
                    <p style={{ color: 'var(--ink-faint)', fontSize: '0.88rem' }}>No circulation recorded yet.</p>
                  ) : (
                    <div className="bars">
                      {borrowed.map((b) => (
                        <div className="bar-row" key={b.bookId}>
                          <span title={b.title} style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.title}</span>
                          <div className="bar-track">
                            <div className="bar-fill" style={{ width: `${(b.borrowCount / maxBorrow) * 100}%` }} />
                          </div>
                          <span className="num">{b.borrowCount}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="panel pad">
                  <div className="section-head">
                    <h2>Desk notes</h2>
                  </div>
                  <p style={{ fontSize: '0.9rem', color: 'var(--ink-soft)', lineHeight: 1.7 }}>
                    {stats.overdueLoans > 0
                      ? `${stats.overdueLoans} loan${stats.overdueLoans === 1 ? '' : 's'} past due. Run the overdue sweep from the Circulation desk to apply notices.`
                      : 'No overdue loans. The shelves are in good order.'}
                  </p>
                  <p style={{ fontSize: '0.9rem', color: 'var(--ink-soft)', lineHeight: 1.7, marginTop: 12 }}>
                    {stats.availableCopies} of {stats.totalCopies} copies are on the shelf and ready to lend.
                  </p>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}
