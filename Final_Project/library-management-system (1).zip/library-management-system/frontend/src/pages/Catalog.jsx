import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager, Badge, Modal } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function Catalog() {
  const { isStaff } = useAuth();
  const toast = useToast();
  const [books, setBooks] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [showAdd, setShowAdd] = useState(false);

  const load = useCallback(async (p = 1, q = '') => {
    setLoading(true);
    try {
      const { data } = await api.get('/books', { params: { page: p, limit: 10, search: q || undefined } });
      setBooks(data.data.books);
      setMeta(data.meta);
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { load(page, search); /* eslint-disable-next-line */ }, [page]);

  const onSearch = (e) => {
    e.preventDefault();
    setPage(1);
    load(1, search);
  };

  return (
    <>
      <Topbar
        title="Catalog"
        sub="The full collection"
        actions={isStaff && <button className="btn" onClick={() => setShowAdd(true)}>+ Add title</button>}
      />
      <div className="content">
        <form className="toolbar" onSubmit={onSearch}>
          <div className="search">
            <input
              placeholder="Search by title, tag, or description…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button className="btn ghost" type="submit">Search</button>
          {search && (
            <button className="btn ghost small" type="button" onClick={() => { setSearch(''); setPage(1); load(1, ''); }}>
              Clear
            </button>
          )}
        </form>

        <div className="panel">
          {loading ? <Loading /> : books.length === 0 ? (
            <Empty title="No titles found" sub="Try a different search, or add the first book." mark="❡" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Authors</th>
                    <th>Category</th>
                    <th>Call No. (ISBN)</th>
                    <th>Copies</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {books.map((b) => (
                    <tr key={b._id}>
                      <td>
                        <div className="cell-title serif" style={{ fontSize: '1rem' }}>{b.title}</div>
                        {b.publicationYear && <div className="cell-sub">{b.publicationYear} · {b.language}</div>}
                      </td>
                      <td>{b.authors?.map((a) => a.name).join(', ') || '—'}</td>
                      <td>{b.category?.name || '—'}</td>
                      <td className="mono" style={{ fontSize: '0.82rem' }}>{b.isbn}</td>
                      <td className="mono">{b.availableCopies}/{b.totalCopies}</td>
                      <td>
                        <Badge status={b.availableCopies > 0 ? 'available' : 'out'} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>

      {showAdd && (
        <AddBookModal
          onClose={() => setShowAdd(false)}
          onSaved={() => { setShowAdd(false); load(page, search); toast.success('Title added to the catalog'); }}
        />
      )}
    </>
  );
}

function AddBookModal({ onClose, onSaved }) {
  const toast = useToast();
  const [authors, setAuthors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [publishers, setPublishers] = useState([]);
  const [form, setForm] = useState({
    title: '', isbn: '', authorId: '', categoryId: '', publisherId: '',
    totalCopies: 1, publicationYear: '', price: '',
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [a, c, p] = await Promise.all([
          api.get('/authors?limit=100'),
          api.get('/categories?limit=100'),
          api.get('/publishers?limit=100'),
        ]);
        setAuthors(a.data.data.authors);
        setCategories(c.data.data.categorys || c.data.data.categories || []);
        setPublishers(p.data.data.publishers);
      } catch (e) { toast.error(errMsg(e)); }
    })();
  }, [toast]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const payload = {
        title: form.title,
        isbn: form.isbn,
        authors: [form.authorId],
        category: form.categoryId,
        totalCopies: Number(form.totalCopies),
      };
      if (form.publisherId) payload.publisher = form.publisherId;
      if (form.publicationYear) payload.publicationYear = Number(form.publicationYear);
      if (form.price) payload.price = Number(form.price);
      await api.post('/books', payload);
      onSaved();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="Add a title" subtitle="Catalog a new book into the collection" onClose={onClose}>
      <form onSubmit={submit}>
        <div className="body">
          <div className="field">
            <label>Title</label>
            <input value={form.title} onChange={set('title')} required />
          </div>
          <div className="field">
            <label>ISBN (10 or 13 digits)</label>
            <input value={form.isbn} onChange={set('isbn')} required placeholder="9780132350884" />
          </div>
          <div className="row">
            <div className="field">
              <label>Author</label>
              <select value={form.authorId} onChange={set('authorId')} required>
                <option value="">Select…</option>
                {authors.map((a) => <option key={a._id} value={a._id}>{a.name}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Category</label>
              <select value={form.categoryId} onChange={set('categoryId')} required>
                <option value="">Select…</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
            </div>
          </div>
          <div className="field">
            <label>Publisher (optional)</label>
            <select value={form.publisherId} onChange={set('publisherId')}>
              <option value="">None</option>
              {publishers.map((p) => <option key={p._id} value={p._id}>{p.name}</option>)}
            </select>
          </div>
          <div className="row">
            <div className="field">
              <label>Total copies</label>
              <input type="number" min="1" value={form.totalCopies} onChange={set('totalCopies')} required />
            </div>
            <div className="field">
              <label>Year</label>
              <input type="number" value={form.publicationYear} onChange={set('publicationYear')} placeholder="2008" />
            </div>
            <div className="field">
              <label>Price (₹)</label>
              <input type="number" value={form.price} onChange={set('price')} placeholder="40" />
            </div>
          </div>
          {(authors.length === 0 || categories.length === 0) && (
            <div className="form-error">
              You need at least one author and one category first. Seed the database or add them via the API.
            </div>
          )}
        </div>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Add to catalog'}</button>
        </div>
      </form>
    </Modal>
  );
}
