import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager, Badge, Modal } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function Circulation() {
  const toast = useToast();
  const [tx, setTx] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState('');
  const [showIssue, setShowIssue] = useState(false);
  const [returning, setReturning] = useState(null);

  const load = useCallback(async (p = 1, status = '') => {
    setLoading(true);
    try {
      const params = { page: p, limit: 10, sort: '-createdAt' };
      if (status) params.status = status;
      const { data } = await api.get('/transactions', { params });
      setTx(data.data.transactions);
      setMeta(data.meta);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { load(page, filter); }, [page, filter, load]);

  const sweep = async () => {
    try {
      const { data } = await api.post('/transactions/jobs/mark-overdue');
      toast.success(data.message);
      load(page, filter);
    } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <>
      <Topbar
        title="Circulation"
        sub="Issue, return, and track every loan"
        actions={
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn ghost" onClick={sweep}>Run overdue sweep</button>
            <button className="btn" onClick={() => setShowIssue(true)}>Issue a book</button>
          </div>
        }
      />
      <div className="content">
        <div className="toolbar">
          {['', 'issued', 'overdue', 'returned', 'lost'].map((s) => (
            <button
              key={s || 'all'}
              className={`btn small ${filter === s ? '' : 'ghost'}`}
              onClick={() => { setFilter(s); setPage(1); }}
            >
              {s === '' ? 'All' : s[0].toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>

        <div className="panel">
          {loading ? <Loading /> : tx.length === 0 ? (
            <Empty title="No transactions" sub="Issue a book to start the circulation record." mark="⇄" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Book</th>
                    <th>Borrower</th>
                    <th>Issued</th>
                    <th>Due</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {tx.map((t) => (
                    <tr key={t._id}>
                      <td className="cell-title">{t.book?.title || '—'}</td>
                      <td>
                        {t.user?.name}
                        <div className="cell-sub mono">{t.user?.membershipId}</div>
                      </td>
                      <td className="mono" style={{ fontSize: '0.82rem' }}>{new Date(t.issueDate).toLocaleDateString()}</td>
                      <td className="mono" style={{ fontSize: '0.82rem' }}>{new Date(t.dueDate).toLocaleDateString()}</td>
                      <td><Badge status={t.status} /></td>
                      <td>
                        {t.status !== 'returned' && t.status !== 'lost' && (
                          <button className="btn ghost small" onClick={() => setReturning(t)}>Return</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>

      {showIssue && (
        <IssueModal
          onClose={() => setShowIssue(false)}
          onDone={() => { setShowIssue(false); load(1, filter); setPage(1); toast.success('Book issued'); }}
        />
      )}
      {returning && (
        <ReturnModal
          tx={returning}
          onClose={() => setReturning(null)}
          onDone={() => { setReturning(null); load(page, filter); toast.success('Book returned'); }}
        />
      )}
    </>
  );
}

function IssueModal({ onClose, onDone }) {
  const toast = useToast();
  const [books, setBooks] = useState([]);
  const [members, setMembers] = useState([]);
  const [form, setForm] = useState({ bookId: '', userId: '', loanDays: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [b, u] = await Promise.all([
          api.get('/books', { params: { available: true, limit: 100 } }),
          api.get('/users', { params: { role: 'member', limit: 100 } }),
        ]);
        setBooks(b.data.data.books);
        setMembers(u.data.data.users);
      } catch (e) { toast.error(errMsg(e)); }
    })();
  }, [toast]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const payload = { bookId: form.bookId, userId: form.userId };
      if (form.loanDays) payload.loanDays = Number(form.loanDays);
      await api.post('/transactions/issue', payload);
      onDone();
    } catch (err) { toast.error(errMsg(err)); }
    finally { setBusy(false); }
  };

  return (
    <Modal title="Issue a book" subtitle="Lend a copy to a member" onClose={onClose}>
      <form onSubmit={submit}>
        <div className="body">
          <div className="field">
            <label>Book (available copies)</label>
            <select value={form.bookId} onChange={set('bookId')} required>
              <option value="">Select a title…</option>
              {books.map((b) => (
                <option key={b._id} value={b._id}>{b.title} — {b.availableCopies} left</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Member</label>
            <select value={form.userId} onChange={set('userId')} required>
              <option value="">Select a member…</option>
              {members.map((m) => (
                <option key={m._id} value={m._id}>{m.name} ({m.membershipId})</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Loan period (days, optional)</label>
            <input type="number" value={form.loanDays} onChange={set('loanDays')} placeholder="14 (default)" />
          </div>
        </div>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Issuing…' : 'Issue book'}</button>
        </div>
      </form>
    </Modal>
  );
}

function ReturnModal({ tx, onClose, onDone }) {
  const toast = useToast();
  const [condition, setCondition] = useState('good');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post(`/transactions/${tx._id}/return`, { condition, notes });
      onDone();
    } catch (err) { toast.error(errMsg(err)); }
    finally { setBusy(false); }
  };

  const overdue = new Date(tx.dueDate) < new Date();

  return (
    <Modal title="Return a book" subtitle={`"${tx.book?.title}" from ${tx.user?.name}`} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="body">
          {overdue && (
            <div className="form-error" style={{ color: 'var(--gold)', borderColor: 'var(--gold)', background: 'rgba(176,131,39,0.08)' }}>
              This loan is past due — an overdue fine will be calculated automatically.
            </div>
          )}
          <div className="field">
            <label>Condition on return</label>
            <select value={condition} onChange={(e) => setCondition(e.target.value)}>
              <option value="good">Good — back on the shelf</option>
              <option value="damaged">Damaged — partial fine</option>
              <option value="lost">Lost — replacement fine</option>
            </select>
          </div>
          <div className="field">
            <label>Notes (optional)</label>
            <textarea rows="2" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Processing…' : 'Confirm return'}</button>
        </div>
      </form>
    </Modal>
  );
}
