import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager, Badge } from '../components/ui';
import { useToast } from '../context/ToastContext';

function dueLabel(t) {
  const due = new Date(t.dueDate);
  const now = new Date();
  const days = Math.ceil((due - now) / (1000 * 60 * 60 * 24));
  if (t.status === 'returned') return `Returned ${new Date(t.returnDate).toLocaleDateString()}`;
  if (days < 0) return `${Math.abs(days)}d overdue`;
  if (days === 0) return 'Due today';
  return `Due in ${days}d`;
}

export default function MyLoans() {
  const toast = useToast();
  const [loans, setLoans] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);

  const load = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const { data } = await api.get('/transactions/my-loans', { params: { page: p, limit: 10, sort: '-createdAt' } });
      setLoans(data.data.transactions);
      setMeta(data.meta);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { load(page); }, [page, load]);

  const renew = async (id) => {
    try {
      await api.post(`/transactions/${id}/renew`, {});
      toast.success('Loan renewed');
      load(page);
    } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <>
      <Topbar title="My Loans" sub="Books you've borrowed" />
      <div className="content">
        <div className="panel">
          {loading ? <Loading /> : loans.length === 0 ? (
            <Empty title="No loans yet" sub="Borrow a book from the catalog to see it here." mark="☐" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Issued</th>
                    <th>Due</th>
                    <th>Renewals</th>
                    <th>Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {loans.map((t) => (
                    <tr key={t._id}>
                      <td className="cell-title serif" style={{ fontSize: '1rem' }}>{t.book?.title || '—'}</td>
                      <td className="mono" style={{ fontSize: '0.82rem' }}>{new Date(t.issueDate).toLocaleDateString()}</td>
                      <td>{dueLabel(t)}</td>
                      <td className="mono">{t.renewalCount}</td>
                      <td><Badge status={t.status} /></td>
                      <td>
                        {(t.status === 'issued') && new Date(t.dueDate) > new Date() && (
                          <button className="btn ghost small" onClick={() => renew(t._id)}>Renew</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>
    </>
  );
}
