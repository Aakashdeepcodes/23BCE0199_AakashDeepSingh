import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager, Badge, Modal } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function Fines() {
  const { isStaff } = useAuth();
  const toast = useToast();
  const [fines, setFines] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [waiving, setWaiving] = useState(null);

  const endpoint = isStaff ? '/fines' : '/fines/my-fines';

  const load = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const { data } = await api.get(endpoint, { params: { page: p, limit: 12, sort: '-createdAt' } });
      setFines(data.data.fines);
      setMeta(data.meta);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [endpoint, toast]);

  useEffect(() => { load(page); }, [page, load]);

  const pay = async (id) => {
    try {
      await api.post(`/fines/${id}/pay`, {});
      toast.success('Fine marked paid');
      load(page);
    } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <>
      <Topbar title="Fines" sub={isStaff ? 'Outstanding and settled charges' : 'Charges on your account'} />
      <div className="content">
        <div className="panel">
          {loading ? <Loading /> : fines.length === 0 ? (
            <Empty title="No fines" sub={isStaff ? 'No charges on record.' : 'Your account is in good standing.'} mark="✓" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {isStaff && <th>Member</th>}
                    <th>Book</th>
                    <th>Reason</th>
                    <th>Amount</th>
                    <th>Status</th>
                    {isStaff && <th></th>}
                  </tr>
                </thead>
                <tbody>
                  {fines.map((f) => (
                    <tr key={f._id}>
                      {isStaff && (
                        <td>
                          <div className="cell-title">{f.user?.name}</div>
                          <div className="cell-sub mono">{f.user?.membershipId}</div>
                        </td>
                      )}
                      <td>{f.book?.title || '—'}</td>
                      <td style={{ textTransform: 'capitalize' }}>
                        {f.reason}{f.daysOverdue ? ` · ${f.daysOverdue}d` : ''}
                      </td>
                      <td className="mono">₹{f.amount}</td>
                      <td><Badge status={f.status} /></td>
                      {isStaff && (
                        <td>
                          {f.status === 'pending' && (
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button className="btn small" onClick={() => pay(f._id)}>Pay</button>
                              <button className="btn ghost small" onClick={() => setWaiving(f)}>Waive</button>
                            </div>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>

      {waiving && (
        <WaiveModal
          fine={waiving}
          onClose={() => setWaiving(null)}
          onDone={() => { setWaiving(null); load(page); toast.success('Fine waived'); }}
        />
      )}
    </>
  );
}

function WaiveModal({ fine, onClose, onDone }) {
  const toast = useToast();
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post(`/fines/${fine._id}/waive`, { reason });
      onDone();
    } catch (err) { toast.error(errMsg(err)); }
    finally { setBusy(false); }
  };

  return (
    <Modal title="Waive fine" subtitle={`₹${fine.amount} for ${fine.user?.name}`} onClose={onClose}>
      <form onSubmit={submit}>
        <div className="body">
          <div className="field">
            <label>Reason for waiving</label>
            <textarea rows="3" value={reason} onChange={(e) => setReason(e.target.value)} required
              placeholder="e.g. first-time member, library error…" />
          </div>
        </div>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Waiving…' : 'Waive fine'}</button>
        </div>
      </form>
    </Modal>
  );
}
