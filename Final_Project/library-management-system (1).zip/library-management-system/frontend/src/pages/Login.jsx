import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api/client';

export default function Login() {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (mode === 'login') await login(form.email, form.password);
      else await register(form);
      navigate('/');
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-art">
        <div className="stamp">Property of The Stacks</div>
        <div>
          <div className="eyebrow" style={{ color: 'var(--oxblood-dim)' }}>Est. MMXXVI · Catalog System</div>
          <h1>Every book, accounted for.</h1>
          <p className="lede">
            A circulation desk for the modern library — issue, return, and renew
            with a record of every transaction kept on the card.
          </p>
        </div>
        <div className="card-lines">
          <div className="ln">CALL NO. ____________________</div>
          <div className="ln">BORROWER ___________________</div>
          <div className="ln">DATE DUE ___________________</div>
        </div>
      </div>

      <div className="login-form-wrap">
        <form className="login-form" onSubmit={submit}>
          <div className="eyebrow">{mode === 'login' ? 'Returning borrower' : 'New borrower'}</div>
          <h2>{mode === 'login' ? 'Sign in' : 'Register'}</h2>
          <p className="switch">
            {mode === 'login' ? 'No card yet? ' : 'Already enrolled? '}
            <button type="button" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}>
              {mode === 'login' ? 'Register here' : 'Sign in'}
            </button>
          </p>

          {error && <div className="form-error">{error}</div>}

          {mode === 'register' && (
            <div className="field">
              <label>Full name</label>
              <input value={form.name} onChange={set('name')} required placeholder="Ada Lovelace" />
            </div>
          )}
          <div className="field">
            <label>Email</label>
            <input type="email" value={form.email} onChange={set('email')} required placeholder="you@example.com" />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={form.password} onChange={set('password')} required placeholder="••••••••" />
          </div>
          {mode === 'register' && (
            <div className="field">
              <label>Phone (optional)</label>
              <input value={form.phone} onChange={set('phone')} placeholder="+1 555 0100" />
            </div>
          )}

          <button className="btn" disabled={busy}>
            {busy ? 'Working…' : mode === 'login' ? 'Sign in' : 'Create account'}
          </button>

          {mode === 'login' && (
            <div className="hint">
              SEEDED ADMIN<br />
              admin@library.com<br />
              Admin@12345
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
