import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function Notifications() {
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [unread, setUnread] = useState(0);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/notifications', { params: { limit: 50, sort: '-createdAt' } });
      setItems(data.data.notifications);
      setUnread(data.meta.unread || 0);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const markAll = async () => {
    try {
      await api.patch('/notifications/read-all');
      toast.success('All notices marked read');
      load();
    } catch (e) { toast.error(errMsg(e)); }
  };

  const markOne = async (id) => {
    try {
      await api.patch(`/notifications/${id}/read`);
      load();
    } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <>
      <Topbar
        title="Notices"
        sub={unread ? `${unread} unread` : 'All caught up'}
        actions={unread > 0 && <button className="btn ghost" onClick={markAll}>Mark all read</button>}
      />
      <div className="content">
        <div className="panel">
          {loading ? <Loading /> : items.length === 0 ? (
            <Empty title="No notices" sub="Issue and due-date notices will appear here." mark="✉" />
          ) : (
            <div>
              {items.map((n) => (
                <div
                  key={n._id}
                  onClick={() => !n.isRead && markOne(n._id)}
                  style={{
                    padding: '16px 24px',
                    borderBottom: '1px solid var(--line)',
                    borderLeft: n.isRead ? '3px solid transparent' : '3px solid var(--oxblood)',
                    cursor: n.isRead ? 'default' : 'pointer',
                    background: n.isRead ? 'transparent' : 'rgba(124,45,39,0.03)',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <strong className="serif" style={{ fontSize: '1.02rem' }}>{n.title}</strong>
                    <span className="mono" style={{ fontSize: '0.72rem', color: 'var(--ink-faint)' }}>
                      {new Date(n.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.9rem', color: 'var(--ink-soft)', marginTop: 4 }}>{n.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
