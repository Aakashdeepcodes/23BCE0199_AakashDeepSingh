import { useEffect, useState, useCallback } from 'react';
import api, { errMsg } from '../api/client';
import { Topbar } from '../components/Layout';
import { Loading, Empty, Pager, Badge } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function Members() {
  const toast = useToast();
  const [users, setUsers] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const load = useCallback(async (p = 1, q = '') => {
    setLoading(true);
    try {
      const { data } = await api.get('/users', { params: { page: p, limit: 12, search: q || undefined } });
      setUsers(data.data.users);
      setMeta(data.meta);
    } catch (e) { toast.error(errMsg(e)); }
    finally { setLoading(false); }
  }, [toast]);

  useEffect(() => { load(page, search); /* eslint-disable-next-line */ }, [page]);

  const onSearch = (e) => { e.preventDefault(); setPage(1); load(1, search); };

  return (
    <>
      <Topbar title="Members" sub="Everyone with a borrowing card" />
      <div className="content">
        <form className="toolbar" onSubmit={onSearch}>
          <div className="search">
            <input placeholder="Search by name or email…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <button className="btn ghost" type="submit">Search</button>
        </form>
        <div className="panel">
          {loading ? <Loading /> : users.length === 0 ? (
            <Empty title="No members found" mark="◇" />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Membership</th>
                    <th>Role</th>
                    <th>On loan</th>
                    <th>Fines</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u._id}>
                      <td>
                        <div className="cell-title">{u.name}</div>
                        <div className="cell-sub">{u.email}</div>
                      </td>
                      <td className="mono" style={{ fontSize: '0.82rem' }}>{u.membershipId || '—'}</td>
                      <td><Badge status={u.role?.name || 'member'} /></td>
                      <td className="mono">{u.booksBorrowedCount}</td>
                      <td className="mono">{u.outstandingFine > 0 ? `₹${u.outstandingFine}` : '—'}</td>
                      <td><Badge status={u.isActive ? 'available' : 'lost'} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <Pager meta={meta} onPage={setPage} />
      </div>
    </>
  );
}
