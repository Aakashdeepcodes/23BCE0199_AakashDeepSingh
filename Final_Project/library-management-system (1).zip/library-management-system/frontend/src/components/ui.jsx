import { useEffect } from 'react';

export function Badge({ status }) {
  const cls = (status || '').toLowerCase();
  return <span className={`badge ${cls}`}>{status}</span>;
}

export function Loading({ label = 'Retrieving records' }) {
  return <div className="loading">{label}…</div>;
}

export function Empty({ title = 'Nothing here yet', sub, mark = '✦' }) {
  return (
    <div className="empty">
      <div className="mark">{mark}</div>
      <h3>{title}</h3>
      {sub && <p>{sub}</p>}
    </div>
  );
}

export function Pager({ meta, onPage }) {
  if (!meta) return null;
  const { page, totalPages, total, hasPrev, hasNext } = meta;
  return (
    <div className="pager">
      <span className="info">
        {total} record{total === 1 ? '' : 's'} · page {page} / {totalPages || 1}
      </span>
      <button className="btn ghost small" disabled={!hasPrev} onClick={() => onPage(page - 1)}>
        ← Prev
      </button>
      <button className="btn ghost small" disabled={!hasNext} onClick={() => onPage(page + 1)}>
        Next →
      </button>
    </div>
  );
}

export function Modal({ title, subtitle, children, onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true">
        <header>
          <h3>{title}</h3>
          {subtitle && <p>{subtitle}</p>}
        </header>
        {children}
      </div>
    </div>
  );
}
