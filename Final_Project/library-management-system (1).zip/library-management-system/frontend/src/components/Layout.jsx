import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Nav items carry a fake "call number" tag to lean into the catalog metaphor.
const NAV = [
  { to: '/', label: 'Reading Room', tag: '000', end: true },
  { to: '/catalog', label: 'Catalog', tag: '010' },
  { to: '/loans', label: 'My Loans', tag: '020' },
  { to: '/circulation', label: 'Circulation', tag: '030', staff: true },
  { to: '/members', label: 'Members', tag: '040', staff: true },
  { to: '/fines', label: 'Fines', tag: '050' },
  { to: '/notifications', label: 'Notices', tag: '060' },
  { to: '/audit', label: 'Audit Log', tag: '070', admin: true },
];

export default function Layout({ children }) {
  const { user, role, isStaff, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const visible = NAV.filter((n) => {
    if (n.admin) return isAdmin;
    if (n.staff) return isStaff;
    return true;
  });

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <h1>The Stacks</h1>
          <div className="sub">Circulation Desk</div>
        </div>
        <nav className="nav">
          {visible.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => (isActive ? 'active' : '')}>
              <span className="tag">{n.tag}</span>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="foot">
          <div className="who">{user?.name}</div>
          <div className="role">{role}</div>
          <button onClick={handleLogout}>Sign out</button>
        </div>
      </aside>
      <div className="main">{children}</div>
    </div>
  );
}

export function Topbar({ title, sub, actions }) {
  return (
    <div className="topbar">
      <div>
        <div className="page-title">{title}</div>
        {sub && <div className="page-sub">{sub}</div>}
      </div>
      {actions && <div>{actions}</div>}
    </div>
  );
}
