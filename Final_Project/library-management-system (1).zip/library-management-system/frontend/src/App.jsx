import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import Layout from './components/Layout';
import { Loading } from './components/ui';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Catalog from './pages/Catalog';
import MyLoans from './pages/MyLoans';
import Circulation from './pages/Circulation';
import Members from './pages/Members';
import Fines from './pages/Fines';
import Notifications from './pages/Notifications';
import Audit from './pages/Audit';

function Protected({ children, staff, admin }) {
  const { user, loading, isStaff, isAdmin } = useAuth();
  if (loading) return <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center' }}><Loading label="Opening the doors" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (admin && !isAdmin) return <Navigate to="/" replace />;
  if (staff && !isStaff) return <Navigate to="/" replace />;
  return <Layout>{children}</Layout>;
}

function PublicOnly({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
            <Route path="/" element={<Protected><Dashboard /></Protected>} />
            <Route path="/catalog" element={<Protected><Catalog /></Protected>} />
            <Route path="/loans" element={<Protected><MyLoans /></Protected>} />
            <Route path="/circulation" element={<Protected staff><Circulation /></Protected>} />
            <Route path="/members" element={<Protected staff><Members /></Protected>} />
            <Route path="/fines" element={<Protected><Fines /></Protected>} />
            <Route path="/notifications" element={<Protected><Notifications /></Protected>} />
            <Route path="/audit" element={<Protected admin><Audit /></Protected>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
