'use strict';

const { User, Role, Notification } = require('../models');
const ApiError = require('../utils/ApiError');
const { generateAuthTokens, verifyRefreshToken } = require('../utils/token');

async function register({ name, email, password, phone }) {
  const exists = await User.findOne({ email });
  if (exists) throw ApiError.conflict('Email already registered');

  const memberRole = await Role.findOne({ name: 'member' });
  if (!memberRole) throw ApiError.internal('Default member role not configured. Run the seeder.');

  const user = await User.create({ name, email, password, phone, role: memberRole._id });

  await Notification.create({
    user: user._id,
    type: 'account',
    title: 'Welcome to the Library',
    message: `Your membership ID is ${user.membershipId}.`,
  });

  const tokens = generateAuthTokens(user);
  await user.setRefreshToken(tokens.refreshToken);
  await user.populate('role');
  return { user, tokens };
}

async function login({ email, password }) {
  const user = await User.findOne({ email }).select('+password').populate('role');
  if (!user) throw ApiError.unauthorized('Invalid credentials');
  if (!user.isActive) throw ApiError.forbidden('Account is deactivated');

  const match = await user.comparePassword(password);
  if (!match) throw ApiError.unauthorized('Invalid credentials');

  const tokens = generateAuthTokens(user);
  await user.setRefreshToken(tokens.refreshToken);
  user.lastLoginAt = new Date();
  await user.save();
  return { user, tokens };
}

async function refreshTokens(refreshToken) {
  let decoded;
  try {
    decoded = verifyRefreshToken(refreshToken);
  } catch {
    throw ApiError.unauthorized('Invalid or expired refresh token');
  }
  const user = await User.findById(decoded.sub).select('+refreshTokenHash').populate('role');
  if (!user) throw ApiError.unauthorized('User not found');

  const valid = await user.compareRefreshToken(refreshToken);
  if (!valid) throw ApiError.unauthorized('Refresh token has been revoked');

  const tokens = generateAuthTokens(user);
  await user.setRefreshToken(tokens.refreshToken);
  return { user, tokens };
}

async function logout(userId) {
  const user = await User.findById(userId).select('+refreshTokenHash');
  if (user) await user.setRefreshToken(null);
}

async function changePassword(userId, currentPassword, newPassword) {
  const user = await User.findById(userId).select('+password');
  if (!user) throw ApiError.notFound('User not found');
  const ok = await user.comparePassword(currentPassword);
  if (!ok) throw ApiError.badRequest('Current password is incorrect');
  user.password = newPassword;
  await user.save();
}

module.exports = { register, login, refreshTokens, logout, changePassword };
