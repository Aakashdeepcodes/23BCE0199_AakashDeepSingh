'use strict';

const { Fine, User, Notification, Transaction, Book, Author, Category, Publisher, Role, AuditLog } = require('../models');
const ApiError = require('../utils/ApiError');
const { buildPagination, paginationMeta } = require('../utils/helpers');

/* ============ FINES ============ */
const fineService = {
  async list(query) {
    const { page, limit, skip, sort } = buildPagination(query);
    const filter = {};
    if (query.status) filter.status = query.status;
    if (query.user) filter.user = query.user;
    const [items, total] = await Promise.all([
      Fine.find(filter)
        .populate([{ path: 'user', select: 'name membershipId' }, { path: 'book', select: 'title' }])
        .sort(sort).skip(skip).limit(limit),
      Fine.countDocuments(filter),
    ]);
    return { items, meta: paginationMeta(page, limit, total) };
  },

  async pay(fineId, amount) {
    const fine = await Fine.findById(fineId);
    if (!fine) throw ApiError.notFound('Fine not found');
    if (fine.status !== 'pending') throw ApiError.conflict(`Fine is already ${fine.status}`);

    const payAmount = amount === undefined ? fine.amount : amount;
    if (payAmount < fine.amount) {
      throw ApiError.badRequest(`Partial payment not allowed. Amount due: ${fine.amount}`);
    }
    fine.status = 'paid';
    fine.paidAmount = fine.amount;
    fine.paidAt = new Date();
    await fine.save();

    const user = await User.findById(fine.user);
    if (user) {
      user.outstandingFine = Math.max(0, user.outstandingFine - fine.amount);
      await user.save();
    }
    await Notification.create({
      user: fine.user, type: 'fine', title: 'Fine Paid',
      message: `Your fine of ${fine.amount} has been cleared.`,
    });
    return fine;
  },

  async waive(fineId, reason, waivedById) {
    const fine = await Fine.findById(fineId);
    if (!fine) throw ApiError.notFound('Fine not found');
    if (fine.status !== 'pending') throw ApiError.conflict(`Fine is already ${fine.status}`);
    fine.status = 'waived';
    fine.waivedBy = waivedById;
    fine.waiveReason = reason;
    await fine.save();

    const user = await User.findById(fine.user);
    if (user) {
      user.outstandingFine = Math.max(0, user.outstandingFine - fine.amount);
      await user.save();
    }
    return fine;
  },
};

/* ============ NOTIFICATIONS ============ */
const notificationService = {
  async listForUser(userId, query) {
    const { page, limit, skip, sort } = buildPagination(query);
    const filter = { user: userId };
    if (query.unread === true) filter.isRead = false;
    const [items, total, unread] = await Promise.all([
      Notification.find(filter).sort(sort).skip(skip).limit(limit),
      Notification.countDocuments(filter),
      Notification.countDocuments({ user: userId, isRead: false }),
    ]);
    return { items, meta: { ...paginationMeta(page, limit, total), unread } };
  },
  async markRead(id, userId) {
    const n = await Notification.findOneAndUpdate(
      { _id: id, user: userId },
      { isRead: true, readAt: new Date() },
      { new: true }
    );
    if (!n) throw ApiError.notFound('Notification not found');
    return n;
  },
  async markAllRead(userId) {
    const r = await Notification.updateMany(
      { user: userId, isRead: false },
      { isRead: true, readAt: new Date() }
    );
    return r.modifiedCount;
  },
};

/* ============ USERS (admin) ============ */
const userService = {
  async list(query) {
    const { page, limit, skip, sort } = buildPagination(query);
    const filter = {};
    if (query.search) filter.$text = { $search: query.search };
    if (query.isActive !== undefined) filter.isActive = query.isActive;
    if (query.role) {
      const role = await Role.findOne({ name: query.role });
      if (role) filter.role = role._id;
    }
    const [items, total] = await Promise.all([
      User.find(filter).populate('role', 'name').sort(sort).skip(skip).limit(limit),
      User.countDocuments(filter),
    ]);
    return { items, meta: paginationMeta(page, limit, total) };
  },
  async get(id) {
    const user = await User.findById(id).populate('role');
    if (!user) throw ApiError.notFound('User not found');
    return user;
  },
  async update(id, payload) {
    const user = await User.findById(id);
    if (!user) throw ApiError.notFound('User not found');
    if (payload.roleName) {
      const role = await Role.findOne({ name: payload.roleName });
      if (!role) throw ApiError.badRequest('Invalid role');
      user.role = role._id;
      delete payload.roleName;
    }
    Object.assign(user, payload);
    await user.save();
    return user.populate('role');
  },
  async deactivate(id) {
    const user = await User.findById(id);
    if (!user) throw ApiError.notFound('User not found');
    user.isActive = false;
    await user.save();
  },
};

/* ============ GENERIC CATALOG CRUD ============ */
function makeCatalogService(Model, label) {
  return {
    async create(payload) {
      const doc = await Model.create(payload);
      return doc;
    },
    async list(query) {
      const { page, limit, skip, sort } = buildPagination(query);
      const filter = {};
      if (query.search) filter.$or = [{ name: new RegExp(query.search, 'i') }];
      const [items, total] = await Promise.all([
        Model.find(filter).sort(sort).skip(skip).limit(limit),
        Model.countDocuments(filter),
      ]);
      return { items, meta: paginationMeta(page, limit, total) };
    },
    async get(id) {
      const doc = await Model.findById(id);
      if (!doc) throw ApiError.notFound(`${label} not found`);
      return doc;
    },
    async update(id, payload) {
      const doc = await Model.findByIdAndUpdate(id, payload, { new: true, runValidators: true });
      if (!doc) throw ApiError.notFound(`${label} not found`);
      return doc;
    },
    async remove(id) {
      const doc = await Model.findByIdAndDelete(id);
      if (!doc) throw ApiError.notFound(`${label} not found`);
    },
  };
}

const authorService = makeCatalogService(Author, 'Author');
const categoryService = makeCatalogService(Category, 'Category');
const publisherService = makeCatalogService(Publisher, 'Publisher');

/* ============ REPORTS (aggregation pipelines) ============ */
const reportService = {
  // Most borrowed books
  async mostBorrowed(limit = 10) {
    return Transaction.aggregate([
      { $group: { _id: '$book', borrowCount: { $sum: 1 } } },
      { $sort: { borrowCount: -1 } },
      { $limit: limit },
      { $lookup: { from: 'books', localField: '_id', foreignField: '_id', as: 'book' } },
      { $unwind: '$book' },
      { $project: { _id: 0, bookId: '$book._id', title: '$book.title', isbn: '$book.isbn', borrowCount: 1 } },
    ]);
  },

  // Active members by borrow volume
  async topMembers(limit = 10) {
    return Transaction.aggregate([
      { $group: { _id: '$user', loans: { $sum: 1 } } },
      { $sort: { loans: -1 } },
      { $limit: limit },
      { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
      { $unwind: '$user' },
      { $project: { _id: 0, userId: '$user._id', name: '$user.name', membershipId: '$user.membershipId', loans: 1 } },
    ]);
  },

  // Fine collection summary
  async fineSummary() {
    const result = await Fine.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          total: { $sum: '$amount' },
        },
      },
    ]);
    const summary = { pending: { count: 0, total: 0 }, paid: { count: 0, total: 0 }, waived: { count: 0, total: 0 } };
    result.forEach((r) => { summary[r._id] = { count: r.count, total: r.total }; });
    return summary;
  },

  // Monthly circulation trend
  async circulationTrend(months = 6) {
    const since = new Date();
    since.setMonth(since.getMonth() - months);
    return Transaction.aggregate([
      { $match: { issueDate: { $gte: since } } },
      {
        $group: {
          _id: { year: { $year: '$issueDate' }, month: { $month: '$issueDate' } },
          issued: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
      {
        $project: {
          _id: 0,
          period: {
            $concat: [
              { $toString: '$_id.year' }, '-',
              { $cond: [{ $lt: ['$_id.month', 10] }, { $concat: ['0', { $toString: '$_id.month' }] }, { $toString: '$_id.month' }] },
            ],
          },
          issued: 1,
        },
      },
    ]);
  },

  // Dashboard overview
  async dashboard() {
    const [
      totalBooks, totalCopiesAgg, totalMembers, activeLoans, overdueLoans, pendingFinesAgg,
    ] = await Promise.all([
      Book.countDocuments({ isActive: true }),
      Book.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: null, total: { $sum: '$totalCopies' }, available: { $sum: '$availableCopies' } } },
      ]),
      User.countDocuments({ isActive: true }),
      Transaction.countDocuments({ status: { $in: ['issued', 'overdue'] } }),
      Transaction.countDocuments({ status: { $in: ['issued', 'overdue'] }, dueDate: { $lt: new Date() } }),
      Fine.aggregate([{ $match: { status: 'pending' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
    ]);
    const copies = totalCopiesAgg[0] || { total: 0, available: 0 };
    return {
      totalBooks,
      totalCopies: copies.total,
      availableCopies: copies.available,
      copiesOnLoan: copies.total - copies.available,
      totalMembers,
      activeLoans,
      overdueLoans,
      pendingFineAmount: pendingFinesAgg[0] ? pendingFinesAgg[0].total : 0,
    };
  },
};

/* ============ AUDIT ============ */
const auditService = {
  async list(query) {
    const { page, limit, skip, sort } = buildPagination(query);
    const filter = {};
    if (query.entity) filter.entity = query.entity;
    if (query.action) filter.action = query.action;
    if (query.actor) filter.actor = query.actor;
    const [items, total] = await Promise.all([
      AuditLog.find(filter).populate('actor', 'name email').sort(sort).skip(skip).limit(limit),
      AuditLog.countDocuments(filter),
    ]);
    return { items, meta: paginationMeta(page, limit, total) };
  },
};

module.exports = {
  fineService, notificationService, userService,
  authorService, categoryService, publisherService,
  reportService, auditService,
};
