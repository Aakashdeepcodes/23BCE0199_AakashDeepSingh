'use strict';

const { Book } = require('../models');
const ApiError = require('../utils/ApiError');
const { buildPagination, paginationMeta } = require('../utils/helpers');

const POPULATE = [
  { path: 'authors', select: 'name nationality' },
  { path: 'category', select: 'name slug' },
  { path: 'publisher', select: 'name' },
];

async function createBook(payload) {
  if (payload.availableCopies === undefined) {
    payload.availableCopies = payload.totalCopies;
  }
  const exists = await Book.findOne({ isbn: payload.isbn });
  if (exists) throw ApiError.conflict('A book with this ISBN already exists');
  const book = await Book.create(payload);
  return book.populate(POPULATE);
}

async function listBooks(query) {
  const { page, limit, skip, sort } = buildPagination(query);
  const filter = { isActive: true };

  if (query.search) filter.$text = { $search: query.search };
  if (query.category) filter.category = query.category;
  if (query.author) filter.authors = query.author;
  if (query.publisher) filter.publisher = query.publisher;
  if (query.language) filter.language = query.language;
  if (query.tag) filter.tags = query.tag;
  if (query.available === true) filter.availableCopies = { $gt: 0 };
  if (query.yearFrom || query.yearTo) {
    filter.publicationYear = {};
    if (query.yearFrom) filter.publicationYear.$gte = query.yearFrom;
    if (query.yearTo) filter.publicationYear.$lte = query.yearTo;
  }

  const [items, total] = await Promise.all([
    Book.find(filter).populate(POPULATE).sort(sort).skip(skip).limit(limit),
    Book.countDocuments(filter),
  ]);

  return { items, meta: paginationMeta(page, limit, total) };
}

async function getBook(id) {
  const book = await Book.findById(id).populate(POPULATE);
  if (!book || !book.isActive) throw ApiError.notFound('Book not found');
  return book;
}

async function updateBook(id, payload) {
  const book = await Book.findById(id);
  if (!book || !book.isActive) throw ApiError.notFound('Book not found');

  // If totalCopies changes, adjust availableCopies by the same delta
  if (payload.totalCopies !== undefined) {
    const delta = payload.totalCopies - book.totalCopies;
    const newAvailable = book.availableCopies + delta;
    if (newAvailable < 0) {
      throw ApiError.badRequest('Cannot reduce total copies below number currently on loan');
    }
    payload.availableCopies = newAvailable;
  }
  Object.assign(book, payload);
  await book.save();
  return book.populate(POPULATE);
}

async function deleteBook(id) {
  const book = await Book.findById(id);
  if (!book || !book.isActive) throw ApiError.notFound('Book not found');
  const onLoan = book.totalCopies - book.availableCopies;
  if (onLoan > 0) throw ApiError.conflict(`Cannot delete: ${onLoan} copies are currently on loan`);
  book.isActive = false; // soft delete
  await book.save();
}

// Aggregation: books grouped by category with availability stats
async function statsByCategory() {
  return Book.aggregate([
    { $match: { isActive: true } },
    {
      $group: {
        _id: '$category',
        titles: { $sum: 1 },
        totalCopies: { $sum: '$totalCopies' },
        availableCopies: { $sum: '$availableCopies' },
      },
    },
    { $lookup: { from: 'categories', localField: '_id', foreignField: '_id', as: 'category' } },
    { $unwind: { path: '$category', preserveNullAndEmptyArrays: true } },
    {
      $project: {
        _id: 0,
        category: '$category.name',
        titles: 1,
        totalCopies: 1,
        availableCopies: 1,
        onLoan: { $subtract: ['$totalCopies', '$availableCopies'] },
      },
    },
    { $sort: { titles: -1 } },
  ]);
}

module.exports = { createBook, listBooks, getBook, updateBook, deleteBook, statsByCategory };
