'use strict';

const mongoose = require('mongoose');
const { Book, User, Transaction, Fine, Notification } = require('../models');
const ApiError = require('../utils/ApiError');
const config = require('../config');
const { buildPagination, paginationMeta } = require('../utils/helpers');

const POPULATE = [
  { path: 'book', select: 'title isbn' },
  { path: 'user', select: 'name email membershipId' },
];

function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function daysBetween(a, b) {
  const ms = new Date(b).getTime() - new Date(a).getTime();
  return Math.max(0, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}

// Use a transaction when the deployment is a replica set; fall back gracefully otherwise.
async function withSession(work) {
  const session = await mongoose.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      result = await work(session);
    });
    return result;
  } catch (err) {
    if (err.message && /Transaction numbers|replica set|not supported/i.test(err.message)) {
      // Standalone Mongo: run without a session
      return work(null);
    }
    throw err;
  } finally {
    await session.endSession();
  }
}

async function issueBook({ bookId, userId, loanDays }, issuedById) {
  return withSession(async (session) => {
    const opts = session ? { session } : {};

    const book = await Book.findById(bookId).session(session || null);
    if (!book || !book.isActive) throw ApiError.notFound('Book not found');
    if (book.availableCopies < 1) throw ApiError.conflict('No copies available');

    const user = await User.findById(userId).session(session || null);
    if (!user) throw ApiError.notFound('Member not found');
    if (!user.isActive) throw ApiError.forbidden('Member account is deactivated');

    if (user.outstandingFine > 0) {
      throw ApiError.forbidden(`Member has an outstanding fine of ${user.outstandingFine}. Clear it before borrowing.`);
    }
    if (user.booksBorrowedCount >= config.library.maxBooksPerUser) {
      throw ApiError.forbidden(`Borrowing limit reached (${config.library.maxBooksPerUser} books)`);
    }

    const duplicate = await Transaction.findOne({
      book: bookId, user: userId, status: { $in: ['issued', 'overdue'] },
    }).session(session || null);
    if (duplicate) throw ApiError.conflict('Member already has this book on loan');

    const days = loanDays || config.library.defaultLoanDays;
    const dueDate = addDays(new Date(), days);

    const [transaction] = await Transaction.create([{
      book: bookId,
      user: userId,
      issuedBy: issuedById,
      issueDate: new Date(),
      dueDate,
      status: 'issued',
    }], opts);

    book.availableCopies -= 1;
    await book.save(opts);

    user.booksBorrowedCount += 1;
    await user.save(opts);

    await Notification.create([{
      user: userId,
      type: 'system',
      title: 'Book Issued',
      message: `"${book.title}" issued. Due on ${dueDate.toDateString()}.`,
      relatedTransaction: transaction._id,
      relatedBook: book._id,
    }], opts);

    return Transaction.findById(transaction._id).populate(POPULATE);
  });
}

async function returnBook(transactionId, { condition = 'good', notes } = {}, returnedById) {
  return withSession(async (session) => {
    const opts = session ? { session } : {};

    const transaction = await Transaction.findById(transactionId).session(session || null);
    if (!transaction) throw ApiError.notFound('Transaction not found');
    if (transaction.status === 'returned') throw ApiError.conflict('Book already returned');

    const book = await Book.findById(transaction.book).session(session || null);
    const user = await User.findById(transaction.user).session(session || null);

    const now = new Date();
    transaction.returnDate = now;
    transaction.returnedBy = returnedById;
    transaction.status = condition === 'lost' ? 'lost' : 'returned';
    if (notes) transaction.notes = notes;

    // Compute fine
    let fineAmount = 0;
    let daysOverdue = 0;
    let reason = 'overdue';

    if (now > transaction.dueDate) {
      daysOverdue = daysBetween(transaction.dueDate, now);
      fineAmount += daysOverdue * config.library.finePerDay;
    }
    if (condition === 'lost') {
      reason = 'lost';
      fineAmount += book ? (book.price || 0) : 0;
    } else if (condition === 'damaged') {
      reason = 'damaged';
      fineAmount += Math.round((book ? book.price || 0 : 0) * 0.3);
    }

    if (fineAmount > 0) {
      const [fine] = await Fine.create([{
        user: transaction.user,
        transaction: transaction._id,
        book: transaction.book,
        amount: fineAmount,
        reason,
        daysOverdue,
        status: 'pending',
      }], opts);
      transaction.fine = fine._id;
      if (user) {
        user.outstandingFine += fineAmount;
      }
      await Notification.create([{
        user: transaction.user,
        type: 'fine',
        title: 'Fine Applied',
        message: `A fine of ${fineAmount} was applied (${reason}).`,
        relatedTransaction: transaction._id,
      }], opts);
    }

    await transaction.save(opts);

    // Restore copy only if not lost
    if (book && condition !== 'lost') {
      book.availableCopies = Math.min(book.totalCopies, book.availableCopies + 1);
      await book.save(opts);
    } else if (book && condition === 'lost') {
      book.totalCopies = Math.max(0, book.totalCopies - 1);
      await book.save(opts);
    }

    if (user) {
      user.booksBorrowedCount = Math.max(0, user.booksBorrowedCount - 1);
      await user.save(opts);
    }

    return Transaction.findById(transaction._id).populate([...POPULATE, { path: 'fine' }]);
  });
}

async function renewBook(transactionId, { loanDays } = {}, actorId) {
  const transaction = await Transaction.findById(transactionId);
  if (!transaction) throw ApiError.notFound('Transaction not found');
  if (transaction.status === 'returned') throw ApiError.conflict('Cannot renew a returned book');
  if (transaction.renewalCount >= config.library.maxRenewals) {
    throw ApiError.forbidden(`Maximum renewals (${config.library.maxRenewals}) reached`);
  }
  if (new Date() > transaction.dueDate) {
    throw ApiError.forbidden('Cannot renew an overdue book. Please return it first.');
  }
  const days = loanDays || config.library.defaultLoanDays;
  transaction.dueDate = addDays(transaction.dueDate, days);
  transaction.renewalCount += 1;
  transaction.returnedBy = undefined;
  await transaction.save();

  await Notification.create({
    user: transaction.user,
    type: 'system',
    title: 'Loan Renewed',
    message: `New due date: ${transaction.dueDate.toDateString()}.`,
    relatedTransaction: transaction._id,
  });

  return Transaction.findById(transaction._id).populate(POPULATE);
}

async function listTransactions(query) {
  const { page, limit, skip, sort } = buildPagination(query);
  const filter = {};
  if (query.status) filter.status = query.status;
  if (query.user) filter.user = query.user;
  if (query.book) filter.book = query.book;
  if (query.overdue === true) {
    filter.status = { $in: ['issued', 'overdue'] };
    filter.dueDate = { $lt: new Date() };
  }

  const [items, total] = await Promise.all([
    Transaction.find(filter).populate([...POPULATE, { path: 'fine', select: 'amount status' }])
      .sort(sort).skip(skip).limit(limit),
    Transaction.countDocuments(filter),
  ]);
  return { items, meta: paginationMeta(page, limit, total) };
}

async function getTransaction(id) {
  const t = await Transaction.findById(id).populate([...POPULATE, { path: 'fine' }]);
  if (!t) throw ApiError.notFound('Transaction not found');
  return t;
}

// Batch job: flag overdue transactions and create reminder notifications
async function markOverdue() {
  const now = new Date();
  const overdue = await Transaction.find({ status: 'issued', dueDate: { $lt: now } });
  const ops = overdue.map(async (t) => {
    t.status = 'overdue';
    await t.save();
    await Notification.create({
      user: t.user,
      type: 'overdue',
      title: 'Book Overdue',
      message: 'A borrowed book is overdue. Please return it to avoid additional fines.',
      relatedTransaction: t._id,
    });
  });
  await Promise.all(ops);
  return overdue.length;
}

module.exports = {
  issueBook, returnBook, renewBook,
  listTransactions, getTransaction, markOverdue,
};
