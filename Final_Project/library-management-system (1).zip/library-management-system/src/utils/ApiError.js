'use strict';

class ApiError extends Error {
  constructor(statusCode, message, details = undefined, isOperational = true) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }

  static badRequest(msg = 'Bad Request', details) { return new ApiError(400, msg, details); }
  static unauthorized(msg = 'Unauthorized', details) { return new ApiError(401, msg, details); }
  static forbidden(msg = 'Forbidden', details) { return new ApiError(403, msg, details); }
  static notFound(msg = 'Resource not found', details) { return new ApiError(404, msg, details); }
  static conflict(msg = 'Conflict', details) { return new ApiError(409, msg, details); }
  static unprocessable(msg = 'Unprocessable Entity', details) { return new ApiError(422, msg, details); }
  static tooMany(msg = 'Too many requests', details) { return new ApiError(429, msg, details); }
  static internal(msg = 'Internal Server Error', details) { return new ApiError(500, msg, details, false); }
}

module.exports = ApiError;
