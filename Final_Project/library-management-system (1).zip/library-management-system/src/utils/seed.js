'use strict';

const { connectDB, disconnectDB } = require('../config/database');
const config = require('../config');
const logger = require('../config/logger');
const { PERMISSIONS } = require('../models/role.model');
const { Role, User, Author, Category, Publisher, Book } = require('../models');

async function seedRoles() {
  const roles = [
    { name: 'admin', description: 'Full system access', permissions: PERMISSIONS, isSystem: true },
    {
      name: 'librarian',
      description: 'Manages catalog and circulation',
      permissions: [
        'book:create', 'book:read', 'book:update', 'book:delete',
        'author:manage', 'category:manage', 'publisher:manage',
        'transaction:issue', 'transaction:return', 'transaction:read',
        'fine:manage', 'report:read',
      ],
      isSystem: true,
    },
    { name: 'member', description: 'Library member', permissions: ['book:read', 'transaction:read'], isSystem: true },
  ];
  const map = {};
  for (const r of roles) {
    const role = await Role.findOneAndUpdate({ name: r.name }, r, { upsert: true, new: true });
    map[r.name] = role;
  }
  logger.info('Roles seeded');
  return map;
}

async function seedAdmin(adminRole) {
  const existing = await User.findOne({ email: config.seed.adminEmail });
  if (existing) {
    logger.info('Admin already exists');
    return existing;
  }
  const admin = await User.create({
    name: 'System Administrator',
    email: config.seed.adminEmail,
    password: config.seed.adminPassword,
    role: adminRole._id,
    isEmailVerified: true,
  });
  logger.info(`Admin created: ${admin.email} / ${config.seed.adminPassword}`);
  return admin;
}

async function seedCatalog() {
  const [fiction, science, tech] = await Promise.all([
    Category.findOneAndUpdate({ name: 'Fiction' }, { name: 'Fiction' }, { upsert: true, new: true }),
    Category.findOneAndUpdate({ name: 'Science' }, { name: 'Science' }, { upsert: true, new: true }),
    Category.findOneAndUpdate({ name: 'Technology' }, { name: 'Technology' }, { upsert: true, new: true }),
  ]);

  const orwell = await Author.findOneAndUpdate(
    { name: 'George Orwell' }, { name: 'George Orwell', nationality: 'British' }, { upsert: true, new: true });
  const sagan = await Author.findOneAndUpdate(
    { name: 'Carl Sagan' }, { name: 'Carl Sagan', nationality: 'American' }, { upsert: true, new: true });
  const martin = await Author.findOneAndUpdate(
    { name: 'Robert C. Martin' }, { name: 'Robert C. Martin', nationality: 'American' }, { upsert: true, new: true });

  const penguin = await Publisher.findOneAndUpdate(
    { name: 'Penguin Books' }, { name: 'Penguin Books', foundedYear: 1935 }, { upsert: true, new: true });
  const prentice = await Publisher.findOneAndUpdate(
    { name: 'Prentice Hall' }, { name: 'Prentice Hall', foundedYear: 1913 }, { upsert: true, new: true });

  const books = [
    { title: '1984', isbn: '9780451524935', authors: [orwell._id], category: fiction._id, publisher: penguin._id, publicationYear: 1949, totalCopies: 5, availableCopies: 5, price: 15, tags: ['dystopia', 'classic'] },
    { title: 'Cosmos', isbn: '9780345539434', authors: [sagan._id], category: science._id, publisher: penguin._id, publicationYear: 1980, totalCopies: 3, availableCopies: 3, price: 20, tags: ['astronomy'] },
    { title: 'Clean Code', isbn: '9780132350884', authors: [martin._id], category: tech._id, publisher: prentice._id, publicationYear: 2008, totalCopies: 4, availableCopies: 4, price: 40, tags: ['software', 'best-practices'] },
  ];
  for (const b of books) {
    await Book.findOneAndUpdate({ isbn: b.isbn }, b, { upsert: true, new: true });
  }
  logger.info('Catalog (categories, authors, publishers, books) seeded');
}

async function run() {
  await connectDB();
  const roles = await seedRoles();
  await seedAdmin(roles.admin);
  await seedCatalog();
  logger.info('Seeding complete');
  await disconnectDB();
  process.exit(0);
}

run().catch((err) => {
  logger.error(`Seed failed: ${err.message}\n${err.stack}`);
  process.exit(1);
});
