'use strict';

// Wraps async route handlers to forward errors to Express error middleware
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

// Standard success envelope
const sendSuccess = (res, statusCode = 200, message = 'Success', data = null, meta = undefined) => {
  const body = { success: true, message };
  if (data !== null && data !== undefined) body.data = data;
  if (meta) body.meta = meta;
  return res.status(statusCode).json(body);
};

// Parse pagination + sorting from query
const buildPagination = (query, { defaultLimit = 20, maxLimit = 100 } = {}) => {
  let page = parseInt(query.page, 10);
  let limit = parseInt(query.limit, 10);
  page = Number.isNaN(page) || page < 1 ? 1 : page;
  limit = Number.isNaN(limit) || limit < 1 ? defaultLimit : Math.min(limit, maxLimit);
  const skip = (page - 1) * limit;

  let sort = { createdAt: -1 };
  if (query.sort && typeof query.sort === 'string') {
    sort = {};
    query.sort.split(',').forEach((field) => {
      const trimmed = field.trim();
      if (!trimmed) return;
      if (trimmed.startsWith('-')) sort[trimmed.slice(1)] = -1;
      else sort[trimmed] = 1;
    });
  }
  return { page, limit, skip, sort };
};

const paginationMeta = (page, limit, total) => ({
  page,
  limit,
  total,
  totalPages: Math.ceil(total / limit) || 0,
  hasNext: page * limit < total,
  hasPrev: page > 1,
});

module.exports = { asyncHandler, sendSuccess, buildPagination, paginationMeta };
