'use strict';

const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const required = ['MONGO_URI', 'JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET'];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  // eslint-disable-next-line no-console
  console.error(`FATAL: Missing required env vars: ${missing.join(', ')}`);
  process.exit(1);
}

const toInt = (val, fallback) => {
  const n = parseInt(val, 10);
  return Number.isNaN(n) ? fallback : n;
};

module.exports = {
  env: process.env.NODE_ENV || 'development',
  isProd: process.env.NODE_ENV === 'production',
  isTest: process.env.NODE_ENV === 'test',
  port: toInt(process.env.PORT, 5000),
  apiPrefix: process.env.API_PREFIX || '/api/v1',

  mongo: {
    uri: process.env.NODE_ENV === 'test'
      ? process.env.MONGO_URI_TEST || process.env.MONGO_URI
      : process.env.MONGO_URI,
  },

  jwt: {
    accessSecret: process.env.JWT_ACCESS_SECRET,
    refreshSecret: process.env.JWT_REFRESH_SECRET,
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  },

  security: {
    saltRounds: toInt(process.env.BCRYPT_SALT_ROUNDS, 12),
    rateLimitWindowMs: toInt(process.env.RATE_LIMIT_WINDOW_MS, 15 * 60 * 1000),
    rateLimitMax: toInt(process.env.RATE_LIMIT_MAX, 300),
  },

  library: {
    defaultLoanDays: toInt(process.env.DEFAULT_LOAN_DAYS, 14),
    maxBooksPerUser: toInt(process.env.MAX_BOOKS_PER_USER, 5),
    finePerDay: toInt(process.env.FINE_PER_DAY, 2),
    maxRenewals: toInt(process.env.MAX_RENEWALS, 2),
  },

  log: {
    level: process.env.LOG_LEVEL || 'info',
    dir: process.env.LOG_DIR || 'logs',
  },

  seed: {
    adminEmail: process.env.SEED_ADMIN_EMAIL || 'admin@library.com',
    adminPassword: process.env.SEED_ADMIN_PASSWORD || 'Admin@12345',
  },
};
