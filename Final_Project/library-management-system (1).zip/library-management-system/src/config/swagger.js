'use strict';

const swaggerJsdoc = require('swagger-jsdoc');
const path = require('path');
const config = require('./index');

const options = {
  definition: {
    openapi: '3.0.3',
    info: {
      title: 'Library Management System API',
      version: '1.0.0',
      description:
        'Production-grade Library Management System backend built with Node.js, Express, '
        + 'MongoDB, and Mongoose. Supports JWT auth, RBAC, circulation, fines, '
        + 'notifications, reports, and audit logging.',
      contact: { name: 'Karmanya Yogi' },
      license: { name: 'MIT' },
    },
    servers: [{ url: config.apiPrefix, description: 'API base path' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
      },
      schemas: {
        ErrorResponse: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: false },
            message: { type: 'string' },
            errors: { type: 'array', items: { type: 'object' } },
          },
        },
        SuccessResponse: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: true },
            message: { type: 'string' },
            data: { type: 'object' },
            meta: { type: 'object' },
          },
        },
      },
    },
  },
  apis: [path.join(__dirname, '../routes/*.js')],
};

module.exports = swaggerJsdoc(options);
