'use strict';

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const swaggerUi = require('swagger-ui-express');

const config = require('./config');
const logger = require('./config/logger');
const swaggerSpec = require('./config/swagger');
const routes = require('./routes');
const { apiLimiter } = require('./middleware/rateLimit.middleware');
const { errorConverter, errorHandler, notFound } = require('./middleware/error.middleware');

const app = express();

app.set('trust proxy', 1);

// Security & parsing
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(mongoSanitize());
app.use(hpp());
app.use(compression());

// HTTP request logging
app.use(morgan(config.isProd ? 'combined' : 'dev', { stream: logger.stream }));

// Rate limiting on the API
app.use(config.apiPrefix, apiLimiter);

// Swagger docs
app.use(
  '/api-docs',
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec, { customSiteTitle: 'LMS API Docs' })
);
app.get('/api-docs.json', (_req, res) => res.json(swaggerSpec));

// Root
app.get('/', (_req, res) =>
  res.json({
    success: true,
    message: 'Library Management System API',
    docs: '/api-docs',
    apiBase: config.apiPrefix,
  }));

// Mount API
app.use(config.apiPrefix, routes);

// 404 + error handling
app.use(notFound);
app.use(errorConverter);
app.use(errorHandler);

module.exports = app;
