'use strict';

module.exports = {
  Role: require('./role.model'),
  User: require('./user.model'),
  Author: require('./author.model'),
  Category: require('./category.model'),
  Publisher: require('./publisher.model'),
  Book: require('./book.model'),
  Transaction: require('./transaction.model'),
  Fine: require('./fine.model'),
  Notification: require('./notification.model'),
  AuditLog: require('./auditLog.model'),
};
