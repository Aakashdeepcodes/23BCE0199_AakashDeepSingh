'use strict';

const { Schema, model } = require('mongoose');

const PERMISSIONS = [
  'book:create', 'book:read', 'book:update', 'book:delete',
  'author:manage', 'category:manage', 'publisher:manage',
  'user:manage', 'role:manage',
  'transaction:issue', 'transaction:return', 'transaction:read',
  'fine:manage', 'report:read', 'audit:read',
];

const roleSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Role name is required'],
      unique: true,
      trim: true,
      lowercase: true,
      enum: {
        values: ['admin', 'librarian', 'member'],
        message: '{VALUE} is not a supported role',
      },
    },
    description: { type: String, trim: true, maxlength: 250 },
    permissions: {
      type: [String],
      enum: PERMISSIONS,
      default: [],
    },
    isSystem: { type: Boolean, default: false }, // protects core roles from deletion
  },
  { timestamps: true }
);

roleSchema.statics.PERMISSIONS = PERMISSIONS;

module.exports = model('Role', roleSchema);
module.exports.PERMISSIONS = PERMISSIONS;
