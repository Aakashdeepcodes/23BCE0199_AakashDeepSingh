'use strict';

const { Schema, model } = require('mongoose');

const fineSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    transaction: { type: Schema.Types.ObjectId, ref: 'Transaction', required: true, index: true },
    book: { type: Schema.Types.ObjectId, ref: 'Book' },
    amount: { type: Number, required: true, min: 0 },
    reason: {
      type: String,
      enum: ['overdue', 'lost', 'damaged', 'other'],
      default: 'overdue',
    },
    daysOverdue: { type: Number, default: 0, min: 0 },
    status: {
      type: String,
      enum: ['pending', 'paid', 'waived'],
      default: 'pending',
      index: true,
    },
    paidAt: { type: Date, default: null },
    paidAmount: { type: Number, default: 0, min: 0 },
    waivedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    waiveReason: { type: String, trim: true },
  },
  { timestamps: true }
);

fineSchema.index({ user: 1, status: 1 });

module.exports = model('Fine', fineSchema);
