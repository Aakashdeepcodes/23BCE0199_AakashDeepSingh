'use strict';

const { Schema, model } = require('mongoose');

const auditLogSchema = new Schema(
  {
    actor: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    actorEmail: { type: String, trim: true },
    action: { type: String, required: true, index: true }, // e.g. CREATE_BOOK, ISSUE_BOOK
    entity: { type: String, required: true, index: true }, // Book, User, Transaction...
    entityId: { type: Schema.Types.ObjectId },
    method: { type: String },
    path: { type: String },
    ip: { type: String },
    userAgent: { type: String },
    statusCode: { type: Number },
    metadata: { type: Schema.Types.Mixed },
  },
  { timestamps: true }
);

auditLogSchema.index({ entity: 1, entityId: 1, createdAt: -1 });
// TTL: auto-expire audit logs after 180 days
auditLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 180 });

module.exports = model('AuditLog', auditLogSchema);
