'use strict';

const { Schema, model } = require('mongoose');

const notificationSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: {
      type: String,
      enum: ['due_reminder', 'overdue', 'fine', 'reservation', 'system', 'account'],
      default: 'system',
      index: true,
    },
    title: { type: String, required: true, trim: true },
    message: { type: String, required: true, trim: true },
    relatedTransaction: { type: Schema.Types.ObjectId, ref: 'Transaction' },
    relatedBook: { type: Schema.Types.ObjectId, ref: 'Book' },
    isRead: { type: Boolean, default: false, index: true },
    readAt: { type: Date, default: null },
  },
  { timestamps: true }
);

notificationSchema.index({ user: 1, isRead: 1, createdAt: -1 });

module.exports = model('Notification', notificationSchema);
