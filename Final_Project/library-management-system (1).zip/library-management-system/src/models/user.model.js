'use strict';

const { Schema, model } = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const userSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      minlength: 2,
      maxlength: 100,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [EMAIL_REGEX, 'Please provide a valid email'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: 8,
      select: false, // never return by default
    },
    phone: {
      type: String,
      trim: true,
      match: [/^[0-9+\-\s()]{7,20}$/, 'Please provide a valid phone number'],
    },
    role: {
      type: Schema.Types.ObjectId,
      ref: 'Role',
      required: [true, 'Role is required'],
      index: true,
    },
    membershipId: {
      type: String,
      unique: true,
      sparse: true,
      trim: true,
    },
    address: {
      street: { type: String, trim: true },
      city: { type: String, trim: true },
      state: { type: String, trim: true },
      country: { type: String, trim: true },
      zip: { type: String, trim: true },
    },
    isActive: { type: Boolean, default: true, index: true },
    isEmailVerified: { type: Boolean, default: false },
    booksBorrowedCount: { type: Number, default: 0, min: 0 },
    outstandingFine: { type: Number, default: 0, min: 0 },
    lastLoginAt: { type: Date },
    refreshTokenHash: { type: String, select: false },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, ret) {
        delete ret.password;
        delete ret.refreshTokenHash;
        delete ret.__v;
        return ret;
      },
    },
  }
);

// Auto-generate membership ID
userSchema.pre('save', async function generateMembership(next) {
  if (this.membershipId) return next();
  const year = new Date().getFullYear();
  const rand = Math.floor(100000 + Math.random() * 900000);
  this.membershipId = `LIB-${year}-${rand}`;
  next();
});

// Hash password on change
userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, config.security.saltRounds);
  next();
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.setRefreshToken = async function setRefreshToken(token) {
  this.refreshTokenHash = token ? await bcrypt.hash(token, config.security.saltRounds) : null;
  return this.save();
};

userSchema.methods.compareRefreshToken = function compareRefreshToken(token) {
  if (!this.refreshTokenHash) return Promise.resolve(false);
  return bcrypt.compare(token, this.refreshTokenHash);
};

userSchema.index({ name: 'text', email: 'text' });

module.exports = model('User', userSchema);
