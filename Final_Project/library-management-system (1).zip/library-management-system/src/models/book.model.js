'use strict';

const { Schema, model } = require('mongoose');

const ISBN_REGEX = /^(?:\d{9}[\dXx]|\d{13})$/;

const bookSchema = new Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      index: true,
    },
    subtitle: { type: String, trim: true },
    isbn: {
      type: String,
      required: [true, 'ISBN is required'],
      unique: true,
      trim: true,
      validate: {
        validator: (v) => ISBN_REGEX.test(v.replace(/[-\s]/g, '')),
        message: 'Invalid ISBN-10 or ISBN-13',
      },
    },
    authors: {
      type: [{ type: Schema.Types.ObjectId, ref: 'Author' }],
      validate: {
        validator: (arr) => Array.isArray(arr) && arr.length > 0,
        message: 'At least one author is required',
      },
    },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: [true, 'Category is required'],
      index: true,
    },
    publisher: { type: Schema.Types.ObjectId, ref: 'Publisher', index: true },
    description: { type: String, trim: true, maxlength: 5000 },
    language: { type: String, trim: true, default: 'English' },
    edition: { type: String, trim: true },
    publicationYear: { type: Number, min: 1400, max: new Date().getFullYear() + 1 },
    pages: { type: Number, min: 1 },
    coverImage: { type: String, trim: true },
    tags: { type: [String], default: [], index: true },
    price: { type: Number, min: 0, default: 0 },
    location: { // shelf location
      shelf: { type: String, trim: true },
      section: { type: String, trim: true },
    },
    totalCopies: {
      type: Number,
      required: true,
      min: [0, 'Total copies cannot be negative'],
      default: 1,
    },
    availableCopies: {
      type: Number,
      required: true,
      min: [0, 'Available copies cannot be negative'],
      default: 1,
      index: true,
    },
    isActive: { type: Boolean, default: true, index: true },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

bookSchema.virtual('isAvailable').get(function isAvailable() {
  return this.availableCopies > 0 && this.isActive;
});

// Keep availableCopies within bounds
bookSchema.pre('validate', function clampCopies(next) {
  if (this.availableCopies > this.totalCopies) {
    this.availableCopies = this.totalCopies;
  }
  next();
});

// Compound + text indexes for optimized search
bookSchema.index({ title: 'text', subtitle: 'text', description: 'text', tags: 'text' });
bookSchema.index({ category: 1, availableCopies: 1 });
bookSchema.index({ publisher: 1, publicationYear: -1 });

module.exports = model('Book', bookSchema);
