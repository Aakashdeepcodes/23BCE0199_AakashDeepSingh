'use strict';

const { Schema, model } = require('mongoose');

const transactionSchema = new Schema(
  {
    book: {
      type: Schema.Types.ObjectId,
      ref: 'Book',
      required: true,
      index: true,
    },
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    issuedBy: { type: Schema.Types.ObjectId, ref: 'User' }, // librarian/admin
    returnedBy: { type: Schema.Types.ObjectId, ref: 'User' },
    status: {
      type: String,
      enum: ['issued', 'returned', 'overdue', 'lost'],
      default: 'issued',
      index: true,
    },
    issueDate: { type: Date, default: Date.now },
    dueDate: { type: Date, required: true, index: true },
    returnDate: { type: Date, default: null },
    renewalCount: { type: Number, default: 0, min: 0 },
    fine: { type: Schema.Types.ObjectId, ref: 'Fine', default: null },
    notes: { type: String, trim: true, maxlength: 500 },
  },
  { timestamps: true }
);

transactionSchema.virtual('isOverdue').get(function isOverdue() {
  if (this.status === 'returned') return false;
  return Date.now() > new Date(this.dueDate).getTime();
});

// Prevent a single user from having duplicate active loans on the same copy
transactionSchema.index({ book: 1, user: 1, status: 1 });
transactionSchema.index({ status: 1, dueDate: 1 });

module.exports = model('Transaction', transactionSchema);
