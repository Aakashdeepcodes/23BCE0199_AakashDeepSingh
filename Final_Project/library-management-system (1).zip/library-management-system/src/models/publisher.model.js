'use strict';

const { Schema, model } = require('mongoose');

const publisherSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Publisher name is required'],
      unique: true,
      trim: true,
      index: true,
    },
    address: { type: String, trim: true },
    email: { type: String, trim: true, lowercase: true },
    phone: { type: String, trim: true },
    website: { type: String, trim: true },
    foundedYear: { type: Number, min: 1400, max: new Date().getFullYear() },
  },
  { timestamps: true }
);

module.exports = model('Publisher', publisherSchema);
