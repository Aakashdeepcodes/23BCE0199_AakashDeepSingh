'use strict';

const { Schema, model } = require('mongoose');

const authorSchema = new Schema(
  {
    name: { type: String, required: [true, 'Author name is required'], trim: true, index: true },
    bio: { type: String, trim: true, maxlength: 2000 },
    nationality: { type: String, trim: true },
    birthDate: { type: Date },
    deathDate: { type: Date },
    website: { type: String, trim: true },
  },
  { timestamps: true }
);

authorSchema.index({ name: 'text', bio: 'text' });

module.exports = model('Author', authorSchema);
