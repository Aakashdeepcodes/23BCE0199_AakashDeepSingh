'use strict';

const { AuditLog } = require('../models');
const logger = require('../config/logger');

// Records mutating actions after the response is sent (non-blocking)
const auditLog = (action, entity) => (req, res, next) => {
  res.on('finish', () => {
    // Only log successful mutations
    if (res.statusCode >= 400) return;
    const entityId = res.locals.auditEntityId
      || req.params.id
      || (res.locals.created && res.locals.created._id);

    AuditLog.create({
      actor: req.user ? req.user._id : undefined,
      actorEmail: req.user ? req.user.email : undefined,
      action,
      entity,
      entityId,
      method: req.method,
      path: req.originalUrl,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      statusCode: res.statusCode,
      metadata: res.locals.auditMeta,
    }).catch((err) => logger.error(`Audit log failed: ${err.message}`));
  });
  next();
};

module.exports = auditLog;
