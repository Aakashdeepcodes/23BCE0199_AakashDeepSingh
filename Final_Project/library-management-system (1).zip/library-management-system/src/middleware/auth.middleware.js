'use strict';

const { User } = require('../models');
const ApiError = require('../utils/ApiError');
const { verifyAccessToken } = require('../utils/token');
const { asyncHandler } = require('../utils/helpers');

// Verifies JWT, attaches req.user (with populated role)
const authenticate = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    throw ApiError.unauthorized('Authentication token missing');
  }
  const token = header.split(' ')[1];
  const decoded = verifyAccessToken(token);

  const user = await User.findById(decoded.sub).populate('role');
  if (!user) throw ApiError.unauthorized('User no longer exists');
  if (!user.isActive) throw ApiError.forbidden('Account is deactivated');

  req.user = user;
  next();
});

// Restrict by role name(s)
const authorizeRoles = (...roleNames) => (req, _res, next) => {
  if (!req.user || !req.user.role) {
    return next(ApiError.unauthorized('Not authenticated'));
  }
  if (!roleNames.includes(req.user.role.name)) {
    return next(ApiError.forbidden('You do not have permission to access this resource'));
  }
  return next();
};

// Restrict by fine-grained permission
const requirePermission = (...perms) => (req, _res, next) => {
  if (!req.user || !req.user.role) {
    return next(ApiError.unauthorized('Not authenticated'));
  }
  const granted = req.user.role.permissions || [];
  const ok = perms.every((p) => granted.includes(p));
  if (!ok && req.user.role.name !== 'admin') {
    return next(ApiError.forbidden('Insufficient permissions'));
  }
  return next();
};

module.exports = { authenticate, authorizeRoles, requirePermission };
