'use strict';

const ApiError = require('../utils/ApiError');

// validate({ body, query, params }) using Joi schemas
const validate = (schema) => (req, _res, next) => {
  const parts = ['body', 'query', 'params'];
  const details = [];

  parts.forEach((part) => {
    if (!schema[part]) return;
    const { error, value } = schema[part].validate(req[part], {
      abortEarly: false,
      stripUnknown: true,
      convert: true,
    });
    if (error) {
      error.details.forEach((d) =>
        details.push({ field: d.path.join('.'), message: d.message.replace(/"/g, '') }));
    } else {
      req[part] = value;
    }
  });

  if (details.length) {
    return next(new ApiError(422, 'Validation failed', details));
  }
  return next();
};

module.exports = validate;
