'use strict';

const authService = require('../services/auth.service');
const { asyncHandler, sendSuccess } = require('../utils/helpers');

const register = asyncHandler(async (req, res) => {
  const { user, tokens } = await authService.register(req.body);
  res.locals.created = user;
  sendSuccess(res, 201, 'Registration successful', { user, tokens });
});

const login = asyncHandler(async (req, res) => {
  const { user, tokens } = await authService.login(req.body);
  sendSuccess(res, 200, 'Login successful', { user, tokens });
});

const refresh = asyncHandler(async (req, res) => {
  const { user, tokens } = await authService.refreshTokens(req.body.refreshToken);
  sendSuccess(res, 200, 'Token refreshed', { user, tokens });
});

const logout = asyncHandler(async (req, res) => {
  await authService.logout(req.user._id);
  sendSuccess(res, 200, 'Logged out successfully');
});

const me = asyncHandler(async (req, res) => {
  sendSuccess(res, 200, 'Current user', { user: req.user });
});

const changePassword = asyncHandler(async (req, res) => {
  await authService.changePassword(req.user._id, req.body.currentPassword, req.body.newPassword);
  sendSuccess(res, 200, 'Password changed successfully');
});

module.exports = { register, login, refresh, logout, me, changePassword };
