'use strict';

const txService = require('../services/transaction.service');
const { asyncHandler, sendSuccess } = require('../utils/helpers');

const issue = asyncHandler(async (req, res) => {
  const transaction = await txService.issueBook(req.body, req.user._id);
  res.locals.created = transaction;
  sendSuccess(res, 201, 'Book issued', { transaction });
});

const returnBook = asyncHandler(async (req, res) => {
  const transaction = await txService.returnBook(req.params.id, req.body, req.user._id);
  res.locals.auditEntityId = transaction._id;
  sendSuccess(res, 200, 'Book returned', { transaction });
});

const renew = asyncHandler(async (req, res) => {
  const transaction = await txService.renewBook(req.params.id, req.body, req.user._id);
  sendSuccess(res, 200, 'Loan renewed', { transaction });
});

const list = asyncHandler(async (req, res) => {
  const { items, meta } = await txService.listTransactions(req.query);
  sendSuccess(res, 200, 'Transactions retrieved', { transactions: items }, meta);
});

const get = asyncHandler(async (req, res) => {
  const transaction = await txService.getTransaction(req.params.id);
  sendSuccess(res, 200, 'Transaction retrieved', { transaction });
});

// Current user's own loans
const myLoans = asyncHandler(async (req, res) => {
  const { items, meta } = await txService.listTransactions({ ...req.query, user: req.user._id.toString() });
  sendSuccess(res, 200, 'Your loans', { transactions: items }, meta);
});

const markOverdue = asyncHandler(async (req, res) => {
  const count = await txService.markOverdue();
  sendSuccess(res, 200, `${count} transactions marked overdue`, { count });
});

module.exports = { issue, returnBook, renew, list, get, myLoans, markOverdue };
