'use strict';

const bookService = require('../services/book.service');
const { asyncHandler, sendSuccess } = require('../utils/helpers');

const create = asyncHandler(async (req, res) => {
  const book = await bookService.createBook(req.body);
  res.locals.created = book;
  sendSuccess(res, 201, 'Book created', { book });
});

const list = asyncHandler(async (req, res) => {
  const { items, meta } = await bookService.listBooks(req.query);
  sendSuccess(res, 200, 'Books retrieved', { books: items }, meta);
});

const get = asyncHandler(async (req, res) => {
  const book = await bookService.getBook(req.params.id);
  sendSuccess(res, 200, 'Book retrieved', { book });
});

const update = asyncHandler(async (req, res) => {
  const book = await bookService.updateBook(req.params.id, req.body);
  sendSuccess(res, 200, 'Book updated', { book });
});

const remove = asyncHandler(async (req, res) => {
  await bookService.deleteBook(req.params.id);
  sendSuccess(res, 200, 'Book deleted');
});

const statsByCategory = asyncHandler(async (req, res) => {
  const stats = await bookService.statsByCategory();
  sendSuccess(res, 200, 'Inventory by category', { stats });
});

module.exports = { create, list, get, update, remove, statsByCategory };
