'use strict';

const {
  fineService, notificationService, userService,
  authorService, categoryService, publisherService,
  reportService, auditService,
} = require('../services/index.service');
const { asyncHandler, sendSuccess } = require('../utils/helpers');

/* ---- Fines ---- */
const fine = {
  list: asyncHandler(async (req, res) => {
    const { items, meta } = await fineService.list(req.query);
    sendSuccess(res, 200, 'Fines retrieved', { fines: items }, meta);
  }),
  myFines: asyncHandler(async (req, res) => {
    const { items, meta } = await fineService.list({ ...req.query, user: req.user._id.toString() });
    sendSuccess(res, 200, 'Your fines', { fines: items }, meta);
  }),
  pay: asyncHandler(async (req, res) => {
    const f = await fineService.pay(req.params.id, req.body.amount);
    sendSuccess(res, 200, 'Fine paid', { fine: f });
  }),
  waive: asyncHandler(async (req, res) => {
    const f = await fineService.waive(req.params.id, req.body.reason, req.user._id);
    sendSuccess(res, 200, 'Fine waived', { fine: f });
  }),
};

/* ---- Notifications ---- */
const notification = {
  list: asyncHandler(async (req, res) => {
    const { items, meta } = await notificationService.listForUser(req.user._id, req.query);
    sendSuccess(res, 200, 'Notifications retrieved', { notifications: items }, meta);
  }),
  markRead: asyncHandler(async (req, res) => {
    const n = await notificationService.markRead(req.params.id, req.user._id);
    sendSuccess(res, 200, 'Marked as read', { notification: n });
  }),
  markAllRead: asyncHandler(async (req, res) => {
    const count = await notificationService.markAllRead(req.user._id);
    sendSuccess(res, 200, `${count} notifications marked read`, { count });
  }),
};

/* ---- Users ---- */
const user = {
  list: asyncHandler(async (req, res) => {
    const { items, meta } = await userService.list(req.query);
    sendSuccess(res, 200, 'Users retrieved', { users: items }, meta);
  }),
  get: asyncHandler(async (req, res) => {
    const u = await userService.get(req.params.id);
    sendSuccess(res, 200, 'User retrieved', { user: u });
  }),
  update: asyncHandler(async (req, res) => {
    const u = await userService.update(req.params.id, req.body);
    sendSuccess(res, 200, 'User updated', { user: u });
  }),
  deactivate: asyncHandler(async (req, res) => {
    await userService.deactivate(req.params.id);
    sendSuccess(res, 200, 'User deactivated');
  }),
};

/* ---- Catalog factory ---- */
function makeCatalogController(service, key) {
  return {
    create: asyncHandler(async (req, res) => {
      const doc = await service.create(req.body);
      res.locals.created = doc;
      sendSuccess(res, 201, `${key} created`, { [key]: doc });
    }),
    list: asyncHandler(async (req, res) => {
      const { items, meta } = await service.list(req.query);
      sendSuccess(res, 200, `${key}s retrieved`, { [`${key}s`]: items }, meta);
    }),
    get: asyncHandler(async (req, res) => {
      const doc = await service.get(req.params.id);
      sendSuccess(res, 200, `${key} retrieved`, { [key]: doc });
    }),
    update: asyncHandler(async (req, res) => {
      const doc = await service.update(req.params.id, req.body);
      sendSuccess(res, 200, `${key} updated`, { [key]: doc });
    }),
    remove: asyncHandler(async (req, res) => {
      await service.remove(req.params.id);
      sendSuccess(res, 200, `${key} deleted`);
    }),
  };
}

const author = makeCatalogController(authorService, 'author');
const category = makeCatalogController(categoryService, 'category');
const publisher = makeCatalogController(publisherService, 'publisher');

/* ---- Reports ---- */
const report = {
  dashboard: asyncHandler(async (req, res) => {
    sendSuccess(res, 200, 'Dashboard', await reportService.dashboard());
  }),
  mostBorrowed: asyncHandler(async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 10;
    sendSuccess(res, 200, 'Most borrowed books', { books: await reportService.mostBorrowed(limit) });
  }),
  topMembers: asyncHandler(async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 10;
    sendSuccess(res, 200, 'Top members', { members: await reportService.topMembers(limit) });
  }),
  fineSummary: asyncHandler(async (req, res) => {
    sendSuccess(res, 200, 'Fine summary', { summary: await reportService.fineSummary() });
  }),
  circulationTrend: asyncHandler(async (req, res) => {
    const months = parseInt(req.query.months, 10) || 6;
    sendSuccess(res, 200, 'Circulation trend', { trend: await reportService.circulationTrend(months) });
  }),
};

/* ---- Audit ---- */
const audit = {
  list: asyncHandler(async (req, res) => {
    const { items, meta } = await auditService.list(req.query);
    sendSuccess(res, 200, 'Audit logs', { logs: items }, meta);
  }),
};

module.exports = { fine, notification, user, author, category, publisher, report, audit };
