'use strict';

const { Joi, objectId, idParam, pagination } = require('./common.validator');

// ---- Transactions ----
const issue = {
  body: Joi.object({
    bookId: objectId.required(),
    userId: objectId.required(),
    loanDays: Joi.number().integer().min(1).max(60),
  }),
};

const returnBook = {
  params: idParam,
  body: Joi.object({
    condition: Joi.string().valid('good', 'damaged', 'lost').default('good'),
    notes: Joi.string().max(500).allow(''),
  }),
};

const renew = {
  params: idParam,
  body: Joi.object({ loanDays: Joi.number().integer().min(1).max(60) }),
};

const listTransactions = {
  query: pagination.keys({
    status: Joi.string().valid('issued', 'returned', 'overdue', 'lost'),
    user: objectId,
    book: objectId,
    overdue: Joi.boolean(),
  }),
};

// ---- Fines ----
const payFine = {
  params: idParam,
  body: Joi.object({ amount: Joi.number().min(0) }),
};

const waiveFine = {
  params: idParam,
  body: Joi.object({ reason: Joi.string().max(300).required() }),
};

// ---- Catalog (author/category/publisher) ----
const author = {
  create: {
    body: Joi.object({
      name: Joi.string().required(),
      bio: Joi.string().max(2000).allow(''),
      nationality: Joi.string().allow(''),
      birthDate: Joi.date(),
      deathDate: Joi.date(),
      website: Joi.string().uri().allow(''),
    }),
  },
  update: { params: idParam, body: Joi.object().min(1) },
};

const category = {
  create: {
    body: Joi.object({
      name: Joi.string().required(),
      description: Joi.string().max(500).allow(''),
      parent: objectId.allow(null),
    }),
  },
  update: { params: idParam, body: Joi.object().min(1) },
};

const publisher = {
  create: {
    body: Joi.object({
      name: Joi.string().required(),
      address: Joi.string().allow(''),
      email: Joi.string().email().allow(''),
      phone: Joi.string().allow(''),
      website: Joi.string().uri().allow(''),
      foundedYear: Joi.number().integer().min(1400).max(new Date().getFullYear()),
    }),
  },
  update: { params: idParam, body: Joi.object().min(1) },
};

// ---- Users (admin) ----
const updateUser = {
  params: idParam,
  body: Joi.object({
    name: Joi.string().min(2).max(100),
    phone: Joi.string(),
    roleName: Joi.string().valid('admin', 'librarian', 'member'),
    isActive: Joi.boolean(),
    address: Joi.object({
      street: Joi.string().allow(''),
      city: Joi.string().allow(''),
      state: Joi.string().allow(''),
      country: Joi.string().allow(''),
      zip: Joi.string().allow(''),
    }),
  }).min(1),
};

module.exports = {
  issue, returnBook, renew, listTransactions,
  payFine, waiveFine,
  author, category, publisher,
  updateUser, idParam,
};
