'use strict';

const { Joi, objectId, idParam, pagination } = require('./common.validator');

const create = {
  body: Joi.object({
    title: Joi.string().min(1).max(300).required(),
    subtitle: Joi.string().max(300).allow(''),
    isbn: Joi.string().required(),
    authors: Joi.array().items(objectId).min(1).required(),
    category: objectId.required(),
    publisher: objectId,
    description: Joi.string().max(5000).allow(''),
    language: Joi.string(),
    edition: Joi.string(),
    publicationYear: Joi.number().integer().min(1400).max(new Date().getFullYear() + 1),
    pages: Joi.number().integer().min(1),
    coverImage: Joi.string().uri().allow(''),
    tags: Joi.array().items(Joi.string()),
    price: Joi.number().min(0),
    location: Joi.object({
      shelf: Joi.string().allow(''),
      section: Joi.string().allow(''),
    }),
    totalCopies: Joi.number().integer().min(0).required(),
    availableCopies: Joi.number().integer().min(0),
  }),
};

const update = {
  params: idParam,
  body: create.body.fork(
    ['title', 'isbn', 'authors', 'category', 'totalCopies'],
    (s) => s.optional()
  ).min(1),
};

const list = {
  query: pagination.keys({
    category: objectId,
    author: objectId,
    publisher: objectId,
    language: Joi.string(),
    available: Joi.boolean(),
    tag: Joi.string(),
    yearFrom: Joi.number().integer(),
    yearTo: Joi.number().integer(),
  }),
};

module.exports = { create, update, list, idParam };
