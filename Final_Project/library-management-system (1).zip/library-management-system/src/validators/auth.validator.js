'use strict';

const { Joi } = require('./common.validator');

const passwordRule = Joi.string()
  .min(8)
  .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/)
  .message('Password must be 8+ chars and include upper, lower, and a number');

const register = {
  body: Joi.object({
    name: Joi.string().min(2).max(100).required(),
    email: Joi.string().email().required(),
    password: passwordRule.required(),
    phone: Joi.string().pattern(/^[0-9+\-\s()]{7,20}$/),
  }),
};

const login = {
  body: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  }),
};

const refresh = {
  body: Joi.object({
    refreshToken: Joi.string().required(),
  }),
};

const changePassword = {
  body: Joi.object({
    currentPassword: Joi.string().required(),
    newPassword: passwordRule.required(),
  }),
};

module.exports = { register, login, refresh, changePassword };
