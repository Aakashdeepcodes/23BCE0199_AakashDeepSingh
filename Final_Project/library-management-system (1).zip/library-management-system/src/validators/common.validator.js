'use strict';

const Joi = require('joi');

const objectId = Joi.string().regex(/^[0-9a-fA-F]{24}$/).message('Invalid ObjectId');

const pagination = Joi.object({
  page: Joi.number().integer().min(1),
  limit: Joi.number().integer().min(1).max(100),
  sort: Joi.string(),
  search: Joi.string().allow(''),
}).unknown(true);

const idParam = Joi.object({ id: objectId.required() });

module.exports = { Joi, objectId, pagination, idParam };
