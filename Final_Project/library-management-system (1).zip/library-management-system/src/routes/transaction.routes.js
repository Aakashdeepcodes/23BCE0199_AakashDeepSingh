'use strict';

const express = require('express');
const ctrl = require('../controllers/transaction.controller');
const validate = require('../middleware/validate.middleware');
const auditLog = require('../middleware/audit.middleware');
const { authenticate, authorizeRoles } = require('../middleware/auth.middleware');
const v = require('../validators/index.validator');
const { idParam } = require('../validators/common.validator');

const router = express.Router();
const staff = authorizeRoles('admin', 'librarian');

/**
 * @swagger
 * tags:
 *   name: Transactions
 *   description: Book issue, return, and renewal
 */

router.use(authenticate);

// Member self-service
router.get('/my-loans', ctrl.myLoans);

/**
 * @swagger
 * /transactions/issue:
 *   post:
 *     summary: Issue a book to a member (staff only)
 *     tags: [Transactions]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [bookId, userId]
 *             properties:
 *               bookId: { type: string }
 *               userId: { type: string }
 *               loanDays: { type: integer }
 *     responses:
 *       201: { description: Issued }
 */
router.post('/issue', staff, validate(v.issue), auditLog('ISSUE_BOOK', 'Transaction'), ctrl.issue);
router.post('/:id/return', staff, validate(v.returnBook), auditLog('RETURN_BOOK', 'Transaction'), ctrl.returnBook);
router.post('/:id/renew', validate(v.renew), auditLog('RENEW_BOOK', 'Transaction'), ctrl.renew);
router.post('/jobs/mark-overdue', staff, ctrl.markOverdue);

router.get('/', staff, validate(v.listTransactions), ctrl.list);
router.get('/:id', validate({ params: idParam }), ctrl.get);

module.exports = router;
