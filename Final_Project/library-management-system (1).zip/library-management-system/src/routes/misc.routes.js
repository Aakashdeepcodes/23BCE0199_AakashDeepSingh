'use strict';

const express = require('express');
const { fine, notification, user, report, audit } = require('../controllers/index.controller');
const validate = require('../middleware/validate.middleware');
const auditLog = require('../middleware/audit.middleware');
const { authenticate, authorizeRoles } = require('../middleware/auth.middleware');
const v = require('../validators/index.validator');
const { idParam } = require('../validators/common.validator');

const staff = authorizeRoles('admin', 'librarian');
const adminOnly = authorizeRoles('admin');

/* ===== Fines ===== */
const fineRoutes = express.Router();
fineRoutes.use(authenticate);
fineRoutes.get('/my-fines', fine.myFines);
fineRoutes.get('/', staff, fine.list);
fineRoutes.post('/:id/pay', staff, validate(v.payFine), auditLog('PAY_FINE', 'Fine'), fine.pay);
fineRoutes.post('/:id/waive', staff, validate(v.waiveFine), auditLog('WAIVE_FINE', 'Fine'), fine.waive);

/* ===== Notifications ===== */
const notificationRoutes = express.Router();
notificationRoutes.use(authenticate);
notificationRoutes.get('/', notification.list);
notificationRoutes.patch('/read-all', notification.markAllRead);
notificationRoutes.patch('/:id/read', validate({ params: idParam }), notification.markRead);

/* ===== Users (admin) ===== */
const userRoutes = express.Router();
userRoutes.use(authenticate, staff);
userRoutes.get('/', user.list);
userRoutes.get('/:id', validate({ params: idParam }), user.get);
userRoutes.put('/:id', adminOnly, validate(v.updateUser), auditLog('UPDATE_USER', 'User'), user.update);
userRoutes.delete('/:id', adminOnly, validate({ params: idParam }), auditLog('DEACTIVATE_USER', 'User'), user.deactivate);

/* ===== Reports ===== */
const reportRoutes = express.Router();
reportRoutes.use(authenticate, staff);
reportRoutes.get('/dashboard', report.dashboard);
reportRoutes.get('/most-borrowed', report.mostBorrowed);
reportRoutes.get('/top-members', report.topMembers);
reportRoutes.get('/fine-summary', report.fineSummary);
reportRoutes.get('/circulation-trend', report.circulationTrend);

/* ===== Audit (admin) ===== */
const auditRoutes = express.Router();
auditRoutes.use(authenticate, adminOnly);
auditRoutes.get('/', audit.list);

module.exports = { fineRoutes, notificationRoutes, userRoutes, reportRoutes, auditRoutes };
