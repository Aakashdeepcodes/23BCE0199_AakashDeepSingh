'use strict';

const express = require('express');
const authRoutes = require('./auth.routes');
const bookRoutes = require('./book.routes');
const transactionRoutes = require('./transaction.routes');
const { authorRoutes, categoryRoutes, publisherRoutes } = require('./catalog.routes');
const { fineRoutes, notificationRoutes, userRoutes, reportRoutes, auditRoutes } = require('./misc.routes');

const router = express.Router();

router.get('/health', (_req, res) =>
  res.json({ success: true, message: 'API is healthy', timestamp: new Date().toISOString() }));

router.use('/auth', authRoutes);
router.use('/books', bookRoutes);
router.use('/authors', authorRoutes);
router.use('/categories', categoryRoutes);
router.use('/publishers', publisherRoutes);
router.use('/transactions', transactionRoutes);
router.use('/fines', fineRoutes);
router.use('/notifications', notificationRoutes);
router.use('/users', userRoutes);
router.use('/reports', reportRoutes);
router.use('/audit-logs', auditRoutes);

module.exports = router;
