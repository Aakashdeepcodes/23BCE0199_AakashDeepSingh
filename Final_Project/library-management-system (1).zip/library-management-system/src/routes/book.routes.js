'use strict';

const express = require('express');
const ctrl = require('../controllers/book.controller');
const validate = require('../middleware/validate.middleware');
const auditLog = require('../middleware/audit.middleware');
const { authenticate, authorizeRoles } = require('../middleware/auth.middleware');
const v = require('../validators/book.validator');
const { idParam } = require('../validators/common.validator');

const router = express.Router();
const staff = authorizeRoles('admin', 'librarian');

/**
 * @swagger
 * tags:
 *   name: Books
 *   description: Book catalog management
 */

/**
 * @swagger
 * /books:
 *   get:
 *     summary: List/search books
 *     tags: [Books]
 *     parameters:
 *       - { in: query, name: page, schema: { type: integer } }
 *       - { in: query, name: limit, schema: { type: integer } }
 *       - { in: query, name: search, schema: { type: string } }
 *       - { in: query, name: category, schema: { type: string } }
 *       - { in: query, name: available, schema: { type: boolean } }
 *     responses:
 *       200: { description: List of books }
 *   post:
 *     summary: Create a book (staff only)
 *     tags: [Books]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       201: { description: Created }
 */
router.get('/', validate(v.list), ctrl.list);
router.get('/stats/by-category', authenticate, staff, ctrl.statsByCategory);

/**
 * @swagger
 * /books/{id}:
 *   get:
 *     summary: Get a book by id
 *     tags: [Books]
 *     parameters:
 *       - { in: path, name: id, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Book }
 *       404: { description: Not found }
 */
router.get('/:id', validate({ params: idParam }), ctrl.get);

router.post('/', authenticate, staff, validate(v.create), auditLog('CREATE_BOOK', 'Book'), ctrl.create);
router.put('/:id', authenticate, staff, validate(v.update), auditLog('UPDATE_BOOK', 'Book'), ctrl.update);
router.delete('/:id', authenticate, staff, validate({ params: idParam }), auditLog('DELETE_BOOK', 'Book'), ctrl.remove);

module.exports = router;
