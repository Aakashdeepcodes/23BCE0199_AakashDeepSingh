'use strict';

const express = require('express');
const { author, category, publisher } = require('../controllers/index.controller');
const validate = require('../middleware/validate.middleware');
const auditLog = require('../middleware/audit.middleware');
const { authenticate, authorizeRoles } = require('../middleware/auth.middleware');
const v = require('../validators/index.validator');
const { idParam } = require('../validators/common.validator');

const staff = authorizeRoles('admin', 'librarian');

function buildRouter(ctrl, vset, entity) {
  const router = express.Router();
  router.get('/', ctrl.list);
  router.get('/:id', validate({ params: idParam }), ctrl.get);
  router.post('/', authenticate, staff, validate(vset.create), auditLog(`CREATE_${entity}`, entity), ctrl.create);
  router.put('/:id', authenticate, staff, validate(vset.update), auditLog(`UPDATE_${entity}`, entity), ctrl.update);
  router.delete('/:id', authenticate, staff, validate({ params: idParam }), auditLog(`DELETE_${entity}`, entity), ctrl.remove);
  return router;
}

/**
 * @swagger
 * tags:
 *   - name: Authors
 *   - name: Categories
 *   - name: Publishers
 */
module.exports = {
  authorRoutes: buildRouter(author, v.author, 'Author'),
  categoryRoutes: buildRouter(category, v.category, 'Category'),
  publisherRoutes: buildRouter(publisher, v.publisher, 'Publisher'),
};
